@echo off
setlocal
cd /d "%~dp0"

echo ========================================
echo  OCC Inventory Manager Windows Build
echo ========================================

if not exist ".venv" (
    echo Creating virtual environment...
    py -m venv .venv
    if errorlevel 1 goto :error
)

call ".venv\Scripts\activate.bat"
if errorlevel 1 goto :error

echo Installing build dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto :error

if exist build rmdir /s /q build
if exist "dist\OCC Inventory Manager" (
    rmdir /s /q "dist\OCC Inventory Manager"
)

echo Building application...
pyinstaller ^
    --noconfirm ^
    --clean ^
    --windowed ^
    --onedir ^
    --name "OCC Inventory Manager" ^
    --collect-all PySide6 ^
    main.py

if errorlevel 1 goto :error

echo.
echo Build complete:
echo dist\OCC Inventory Manager\OCC Inventory Manager.exe
pause
exit /b 0

:error
echo.
echo Build failed. Review the messages above.
pause
exit /b 1
