"""
One-click graphical Windows builder for OCC Inventory Manager.

The builder uses the installed Python interpreter directly, builds the
standalone application executable, and then compiles the Inno Setup installer.
"""

from __future__ import annotations

import os
import queue
import shutil
import subprocess
import sys
import threading
import traceback
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


PROJECT_DIR = Path(__file__).resolve().parent
APP_NAME = "OCC Inventory Manager"
APP_EXE = PROJECT_DIR / f"{APP_NAME}.exe"
ISS_FILE = PROJECT_DIR / "OCC_Inventory_Manager.iss"
REQUIREMENTS_FILE = PROJECT_DIR / "requirements.txt"
BUILD_LOG = PROJECT_DIR / "build_error.log"
DEFAULT_INSTALLER_OUTPUT = PROJECT_DIR


def console_python() -> Path:
    """Return python.exe even when this script was launched with pythonw.exe."""
    executable = Path(sys.executable)
    if executable.name.lower() == "pythonw.exe":
        candidate = executable.with_name("python.exe")
        if candidate.exists():
            return candidate
    return executable


PYTHON_EXE = console_python()


class BuildWindow:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("OCC Inventory Manager Builder")
        self.root.geometry("780x580")
        self.root.minsize(700, 520)
        self.root.report_callback_exception = self.handle_tk_exception

        self.messages = queue.Queue()
        self.is_building = False

        outer = ttk.Frame(root, padding=24)
        outer.pack(fill="both", expand=True)

        ttk.Label(
            outer,
            text="Build OCC Inventory Manager",
            font=("Segoe UI", 18, "bold"),
        ).pack(anchor="w")

        ttk.Label(
            outer,
            text="Build the application and Windows installer in one operation.",
            wraplength=700,
        ).pack(anchor="w", pady=(4, 18))

        ttk.Label(
            outer,
            text="Installer output folder",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w")

        folder_row = ttk.Frame(outer)
        folder_row.pack(fill="x", pady=(6, 14))

        self.output_var = tk.StringVar(value=str(DEFAULT_INSTALLER_OUTPUT))
        self.output_entry = ttk.Entry(folder_row, textvariable=self.output_var)
        self.output_entry.pack(side="left", fill="x", expand=True)

        self.browse_button = ttk.Button(
            folder_row,
            text="Browse…",
            command=self.choose_output,
        )
        self.browse_button.pack(side="left", padx=(8, 0))

        self.progress = ttk.Progressbar(outer, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(2, 8))

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(outer, textvariable=self.status_var).pack(anchor="w", pady=(0, 10))

        ttk.Label(
            outer,
            text="Build activity",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w")

        log_frame = ttk.Frame(outer)
        log_frame.pack(fill="both", expand=True, pady=(6, 14))

        self.log = tk.Text(
            log_frame,
            wrap="word",
            state="disabled",
            font=("Consolas", 9),
        )
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        self.log.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        buttons = ttk.Frame(outer)
        buttons.pack(fill="x")

        self.start_button = ttk.Button(
            buttons,
            text="Build Application and Installer",
            command=self.start_build,
        )
        self.start_button.pack(side="right")

        ttk.Button(buttons, text="Close", command=self.root.destroy).pack(
            side="right", padx=(0, 8)
        )

        self.append_log(f"Python: {PYTHON_EXE}")
        self.append_log("Ready to build.")
        self.root.after(100, self.process_messages)

    def handle_tk_exception(self, exc_type, exc_value, exc_traceback) -> None:
        details = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        self.write_error_log(details)
        messagebox.showerror(
            "Builder error",
            f"An unexpected builder error occurred.\n\n{exc_value}\n\n"
            f"Details were saved to:\n{BUILD_LOG}",
        )

    def write_error_log(self, details: str) -> None:
        timestamp = datetime.now().isoformat(timespec="seconds")
        BUILD_LOG.write_text(
            f"OCC Inventory Manager build error\n"
            f"Time: {timestamp}\n"
            f"Python: {PYTHON_EXE}\n\n{details}",
            encoding="utf-8",
        )

    def choose_output(self) -> None:
        selected = filedialog.askdirectory(
            title="Choose installer output folder",
            initialdir=self.output_var.get() or str(PROJECT_DIR),
        )
        if selected:
            self.output_var.set(selected)

    def append_log(self, text: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")
        self.root.update_idletasks()

    def set_controls_enabled(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        self.start_button.configure(state=state)
        self.output_entry.configure(state=state)
        self.browse_button.configure(state=state)

    def start_build(self) -> None:
        if self.is_building:
            return

        output_text = self.output_var.get().strip()
        if not output_text:
            messagebox.showwarning(
                "Output folder required",
                "Choose where the completed installer should be saved.",
            )
            return

        output = Path(output_text).expanduser()

        try:
            output.mkdir(parents=True, exist_ok=True)
            test_file = output / ".occ_write_test"
            test_file.write_text("test", encoding="utf-8")
            test_file.unlink()
        except OSError as exc:
            messagebox.showerror(
                "Output folder unavailable",
                f"The selected output folder is not writable.\n\n{exc}",
            )
            return

        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        self.append_log("Build requested.")
        self.append_log(f"Installer output: {output}")
        self.progress["value"] = 1
        self.status_var.set("Starting build…")
        self.is_building = True
        self.set_controls_enabled(False)

        worker = threading.Thread(
            target=self.run_build,
            args=(output,),
            daemon=True,
            name="occ-build-worker",
        )
        worker.start()

        self.root.after(500, lambda: self.verify_worker_started(worker))

    def verify_worker_started(self, worker: threading.Thread) -> None:
        if self.is_building and not worker.is_alive() and self.progress["value"] <= 1:
            self.finish_failure(
                "The build worker stopped before starting. "
                f"Review {BUILD_LOG} for details."
            )

    def emit_log(self, text: str) -> None:
        self.messages.put(("log", text))

    def emit_progress(self, value: int) -> None:
        self.messages.put(("progress", value))

    def emit_status(self, text: str) -> None:
        self.messages.put(("status", text))

    def process_messages(self) -> None:
        try:
            while True:
                kind, value = self.messages.get_nowait()
                if kind == "log":
                    self.append_log(str(value))
                elif kind == "progress":
                    self.progress["value"] = int(value)
                elif kind == "status":
                    self.status_var.set(str(value))
                elif kind == "finished":
                    success, detail = value
                    if success:
                        self.finish_success(Path(detail))
                    else:
                        self.finish_failure(str(detail))
        except queue.Empty:
            pass
        finally:
            self.root.after(100, self.process_messages)

    def finish_success(self, output_folder: Path) -> None:
        self.is_building = False
        self.set_controls_enabled(True)
        self.status_var.set("Build complete")
        self.progress["value"] = 100
        if messagebox.askyesno(
            "Build complete",
            "The application and installer were created successfully.\n\n"
            "Open the installer output folder?",
        ):
            os.startfile(str(output_folder))

    def finish_failure(self, detail: str) -> None:
        self.is_building = False
        self.set_controls_enabled(True)
        self.status_var.set("Build failed")
        self.write_error_log(detail)
        messagebox.showerror(
            "Build failed",
            f"The build could not be completed.\n\n{detail}\n\n"
            f"Details were saved to:\n{BUILD_LOG}",
        )

    def run_command(self, command: list[str], cwd: Path) -> None:
        self.emit_log("> " + subprocess.list2cmdline(command))
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0

        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags,
        )

        if process.stdout is None:
            raise RuntimeError("The build process did not provide output.")

        for line in process.stdout:
            self.emit_log(line.rstrip())

        return_code = process.wait()
        if return_code != 0:
            raise RuntimeError(
                f"Command failed with exit code {return_code}:\n"
                f"{subprocess.list2cmdline(command)}"
            )

    def find_inno_compiler(self) -> Path:
        candidates = []

        found = shutil.which("ISCC.exe")
        if found:
            candidates.append(Path(found))

        for variable in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
            base = os.environ.get(variable)
            if not base:
                continue
            if variable == "LOCALAPPDATA":
                candidates.append(Path(base) / "Programs" / "Inno Setup 6" / "ISCC.exe")
            else:
                candidates.append(Path(base) / "Inno Setup 6" / "ISCC.exe")

        for candidate in candidates:
            if candidate.is_file():
                return candidate

        raise RuntimeError(
            "Inno Setup 6 was not found. Install Inno Setup 6 and run "
            "build.bat again."
        )

    def run_build(self, installer_output: Path) -> None:
        try:
            self.emit_status("Checking project files…")
            self.emit_log("Step 1 of 6: Checking project files…")
            self.emit_progress(8)

            required = [
                PROJECT_DIR / "main.py",
                REQUIREMENTS_FILE,
                ISS_FILE,
            ]
            missing = [str(path.name) for path in required if not path.is_file()]
            if missing:
                raise RuntimeError(
                    "Required project files are missing: " + ", ".join(missing)
                )

            self.emit_status("Installing build requirements…")
            self.emit_log("")
            self.emit_log("Step 2 of 6: Installing project requirements…")
            self.emit_progress(20)
            self.run_command(
                [str(PYTHON_EXE), "-m", "pip", "install", "--upgrade", "pip"],
                PROJECT_DIR,
            )
            self.run_command(
                [
                    str(PYTHON_EXE),
                    "-m",
                    "pip",
                    "install",
                    "-r",
                    str(REQUIREMENTS_FILE),
                ],
                PROJECT_DIR,
            )

            self.emit_status("Preparing application build…")
            self.emit_log("")
            self.emit_log("Step 3 of 6: Preparing the application build…")
            self.emit_progress(38)

            build_dir = PROJECT_DIR / "build"
            spec_file = PROJECT_DIR / f"{APP_NAME}.spec"

            if build_dir.exists():
                shutil.rmtree(build_dir, ignore_errors=True)
            if spec_file.exists():
                spec_file.unlink()
            if APP_EXE.exists():
                APP_EXE.unlink()

            self.emit_status("Building application executable…")
            self.emit_log("")
            self.emit_log("Step 4 of 6: Building the standalone executable…")
            self.emit_progress(50)
            self.run_command(
                [
                    str(PYTHON_EXE),
                    "-m",
                    "PyInstaller",
                    "--noconfirm",
                    "--clean",
                    "--windowed",
                    "--onefile",
                    "--name",
                    APP_NAME,
                    "--distpath",
                    str(PROJECT_DIR),
                    "--workpath",
                    str(build_dir),
                    "--specpath",
                    str(PROJECT_DIR),
                    "--collect-all",
                    "PySide6",
                    str(PROJECT_DIR / "main.py"),
                ],
                PROJECT_DIR,
            )

            if not APP_EXE.is_file():
                raise RuntimeError(
                    "PyInstaller completed, but OCC Inventory Manager.exe "
                    "was not created in the project folder."
                )

            self.emit_status("Locating Inno Setup…")
            self.emit_log("")
            self.emit_log("Step 5 of 6: Locating Inno Setup…")
            self.emit_progress(76)
            iscc = self.find_inno_compiler()
            self.emit_log(f"Inno Setup compiler: {iscc}")

            self.emit_status("Compiling installer…")
            self.emit_log("")
            self.emit_log("Step 6 of 6: Compiling the Windows installer…")
            self.emit_progress(86)
            self.run_command(
                [
                    str(iscc),
                    f"/O{installer_output}",
                    str(ISS_FILE),
                ],
                PROJECT_DIR,
            )

            installer = installer_output / "OCC_Inventory_Manager_Setup.exe"
            if not installer.is_file():
                raise RuntimeError(
                    "Inno Setup completed, but the installer was not found at:\n"
                    f"{installer}"
                )

            self.emit_log("")
            self.emit_log("Build completed successfully.")
            self.emit_log(f"Application: {APP_EXE}")
            self.emit_log(f"Installer: {installer}")
            self.messages.put(("finished", (True, str(installer_output))))

        except Exception:
            details = traceback.format_exc()
            self.write_error_log(details)
            self.emit_log("")
            self.emit_log(details)
            self.messages.put(("finished", (False, details)))


def main() -> int:
    root = tk.Tk()
    BuildWindow(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
