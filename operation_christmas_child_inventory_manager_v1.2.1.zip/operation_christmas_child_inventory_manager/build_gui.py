"""
Graphical Windows build utility for OCC Inventory Manager.

Author: usr-bin-share
License: GNU GPL v3.0 or later
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

PROJECT_DIR = Path(__file__).resolve().parent
VENV_DIR = PROJECT_DIR / ".venv"
DEFAULT_OUTPUT = PROJECT_DIR


class BuildSignals(QObject):
    log = Signal(str)
    progress = Signal(int)
    finished = Signal(bool, str)


class BuildWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.signals = BuildSignals()

        self.setWindowTitle("OCC Inventory Manager Builder")
        self.resize(760, 540)
        self.setMinimumSize(680, 480)

        title = QLabel("Build OCC Inventory Manager")
        title.setObjectName("Title")

        subtitle = QLabel(
            "Choose where the finished Windows application should be created, "
            "then start the guided build."
        )
        subtitle.setWordWrap(True)
        subtitle.setObjectName("Subtitle")

        self.output_edit = QLineEdit(str(DEFAULT_OUTPUT))
        browse_button = QPushButton("Browse…")
        browse_button.clicked.connect(self.choose_output_folder)

        folder_row = QHBoxLayout()
        folder_row.addWidget(self.output_edit, 1)
        folder_row.addWidget(browse_button)

        folder_label = QLabel("Build output folder")
        folder_label.setObjectName("SectionLabel")

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)

        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setPlaceholderText("Build steps will appear here…")

        self.start_button = QPushButton("Start Build")
        self.start_button.setObjectName("AccentButton")
        self.start_button.clicked.connect(self.start_build)

        close_button = QPushButton("Close")
        close_button.clicked.connect(self.close)

        button_row = QHBoxLayout()
        button_row.addStretch()
        button_row.addWidget(self.start_button)
        button_row.addWidget(close_button)

        central = QWidget()
        central.setObjectName("Root")
        layout = QVBoxLayout(central)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(6)
        layout.addWidget(folder_label)
        layout.addLayout(folder_row)
        layout.addSpacing(8)
        layout.addWidget(self.progress)
        layout.addWidget(QLabel("Build steps"))
        layout.addWidget(self.log_view, 1)
        layout.addLayout(button_row)
        self.setCentralWidget(central)

        self.setStyleSheet(
            "QWidget#Root { background: #f4f6f9; }"
            "QWidget { font-family: 'Segoe UI'; font-size: 10pt; }"
            "QLabel#Title { font-size: 22px; font-weight: 700; color: #14213d; }"
            "QLabel#Subtitle { color: #64748b; }"
            "QLabel#SectionLabel { font-weight: 600; }"
            "QLineEdit, QTextEdit { background: white; border: 1px solid #cbd5e1; "
            "border-radius: 7px; padding: 7px; }"
            "QPushButton { background: #14213d; color: white; border: none; "
            "border-radius: 7px; padding: 8px 14px; font-weight: 600; }"
            "QPushButton:hover { background: #23395d; }"
            "QPushButton#AccentButton { background: #fca311; color: #14213d; "
            "font-weight: 700; padding: 10px 18px; }"
            "QPushButton#AccentButton:hover { background: #ffb52f; }"
            "QPushButton:disabled { background: #cbd5e1; color: #64748b; }"
            "QProgressBar { background: white; border: 1px solid #cbd5e1; "
            "border-radius: 7px; min-height: 22px; text-align: center; }"
            "QProgressBar::chunk { background: #fca311; border-radius: 6px; }"
        )

        self.signals.log.connect(self.append_log)
        self.signals.progress.connect(self.progress.setValue)
        self.signals.finished.connect(self.build_finished)

    def choose_output_folder(self) -> None:
        selected = QFileDialog.getExistingDirectory(
            self,
            "Choose build output folder",
            self.output_edit.text() or str(PROJECT_DIR),
        )
        if selected:
            self.output_edit.setText(selected)

    def append_log(self, text: str) -> None:
        self.log_view.append(text)
        cursor = self.log_view.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        self.log_view.setTextCursor(cursor)

    def start_build(self) -> None:
        raw_output = self.output_edit.text().strip()
        if not raw_output:
            QMessageBox.warning(
                self,
                "Choose an output folder",
                "Select where the finished application should be created.",
            )
            return

        output_dir = Path(raw_output)
        try:
            output_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            QMessageBox.critical(
                self,
                "Invalid output folder",
                f"The selected folder could not be created.\n\n{exc}",
            )
            return

        self.start_button.setEnabled(False)
        self.output_edit.setEnabled(False)
        self.progress.setValue(0)
        self.log_view.clear()

        threading.Thread(
            target=self.run_build,
            args=(output_dir,),
            daemon=True,
        ).start()

    def run_command(self, command: list[str]) -> None:
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        process = subprocess.Popen(
            command,
            cwd=PROJECT_DIR,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags,
        )
        assert process.stdout is not None
        for line in process.stdout:
            self.signals.log.emit(line.rstrip())
        return_code = process.wait()
        if return_code != 0:
            raise RuntimeError(
                f"A build command failed with exit code {return_code}."
            )

    def run_build(self, output_dir: Path) -> None:
        try:
            self.signals.log.emit("Step 1 of 5: Checking Python environment…")
            self.signals.progress.emit(8)

            if not VENV_DIR.exists():
                self.signals.log.emit("Creating a private Python environment…")
                self.run_command([sys.executable, "-m", "venv", str(VENV_DIR)])
            else:
                self.signals.log.emit("Existing private environment found.")

            python_exe = (
                VENV_DIR / "Scripts" / "python.exe"
                if os.name == "nt"
                else VENV_DIR / "bin" / "python"
            )

            self.signals.log.emit("")
            self.signals.log.emit("Step 2 of 5: Installing required components…")
            self.signals.progress.emit(25)
            self.run_command([
                str(python_exe), "-m", "pip", "install", "--upgrade", "pip"
            ])
            self.run_command([
                str(python_exe), "-m", "pip", "install", "-r",
                str(PROJECT_DIR / "requirements.txt")
            ])

            self.signals.log.emit("")
            self.signals.log.emit("Step 3 of 5: Preparing the output folder…")
            self.signals.progress.emit(45)
            work_dir = PROJECT_DIR / "build"
            spec_file = PROJECT_DIR / "OCC Inventory Manager.spec"
            shutil.rmtree(work_dir, ignore_errors=True)
            if spec_file.exists():
                spec_file.unlink()

            app_output = output_dir / "OCC Inventory Manager"
            shutil.rmtree(app_output, ignore_errors=True)

            self.signals.log.emit("")
            self.signals.log.emit("Step 4 of 5: Building the Windows application…")
            self.signals.progress.emit(60)
            self.run_command([
                str(python_exe), "-m", "PyInstaller",
                "--noconfirm", "--clean", "--windowed", "--onedir",
                "--name", "OCC Inventory Manager",
                "--distpath", str(output_dir),
                "--workpath", str(work_dir),
                "--specpath", str(PROJECT_DIR),
                "--collect-all", "PySide6",
                str(PROJECT_DIR / "main.py"),
            ])

            self.signals.log.emit("")
            self.signals.log.emit("Step 5 of 5: Verifying the finished application…")
            self.signals.progress.emit(92)
            executable = app_output / "OCC Inventory Manager.exe"
            if os.name == "nt" and not executable.exists():
                raise RuntimeError(
                    "The build completed, but the application executable was not found."
                )

            self.signals.progress.emit(100)
            self.signals.log.emit("")
            self.signals.log.emit("Build completed successfully.")
            self.signals.log.emit(f"Application folder: {app_output}")
            self.signals.finished.emit(True, str(app_output))
        except Exception as exc:
            self.signals.log.emit("")
            self.signals.log.emit(f"Build failed: {exc}")
            self.signals.finished.emit(False, str(exc))

    def build_finished(self, success: bool, detail: str) -> None:
        self.start_button.setEnabled(True)
        self.output_edit.setEnabled(True)
        if success:
            answer = QMessageBox.question(
                self,
                "Build complete",
                "The Windows application was created successfully.\n\n"
                "Open the output folder now?",
            )
            if answer == QMessageBox.StandardButton.Yes and os.name == "nt":
                os.startfile(detail)
        else:
            QMessageBox.critical(
                self,
                "Build failed",
                "The build could not be completed.\n\n"
                f"{detail}\n\nSee the build steps for more information.",
            )


def main() -> int:
    app = QApplication(sys.argv)
    window = BuildWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
