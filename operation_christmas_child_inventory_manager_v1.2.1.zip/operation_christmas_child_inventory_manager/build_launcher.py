"""
Bootstrap launcher for the graphical build utility.

This file intentionally uses only the Python standard library so it can
install PySide6 before starting build_gui.py.
"""

from __future__ import annotations

import os
import subprocess
import sys
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import messagebox


PROJECT_DIR = Path(__file__).resolve().parent
VENV_DIR = PROJECT_DIR / ".builder_venv"


def show_error(title: str, message: str) -> None:
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror(title, message)
    root.destroy()


def run(command: list[str]) -> None:
    creationflags = 0
    if os.name == "nt":
        creationflags = subprocess.CREATE_NO_WINDOW

    result = subprocess.run(
        command,
        cwd=PROJECT_DIR,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=creationflags,
    )
    if result.returncode != 0:
        details = (result.stdout + "\n" + result.stderr).strip()
        raise RuntimeError(details or f"Command failed: {' '.join(command)}")


def main() -> int:
    try:
        if not VENV_DIR.exists():
            run([sys.executable, "-m", "venv", str(VENV_DIR)])

        pythonw = VENV_DIR / "Scripts" / "pythonw.exe"
        python = VENV_DIR / "Scripts" / "python.exe"

        if not python.exists():
            raise RuntimeError("The builder Python environment could not be created.")

        check = subprocess.run(
            [str(python), "-c", "import PySide6"],
            cwd=PROJECT_DIR,
            capture_output=True,
            text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )

        if check.returncode != 0:
            run([str(python), "-m", "pip", "install", "--upgrade", "pip"])
            run([str(python), "-m", "pip", "install", "PySide6>=6.8,<7"])

        executable = pythonw if pythonw.exists() else python
        subprocess.Popen(
            [str(executable), str(PROJECT_DIR / "build_gui.py")],
            cwd=PROJECT_DIR,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        return 0

    except Exception as exc:
        show_error(
            "OCC Inventory Manager Builder",
            "The graphical builder could not start.\n\n"
            f"{exc}\n\n"
            "Make sure Python 3.11 or newer is installed and that this computer "
            "has an internet connection for the first launch.",
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
