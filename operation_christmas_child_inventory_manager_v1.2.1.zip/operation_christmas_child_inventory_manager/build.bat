@echo off
setlocal
cd /d "%~dp0"

where pyw >nul 2>nul
if %errorlevel%==0 (
    start "" pyw build_launcher.py
    exit /b 0
)

where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw build_launcher.py
    exit /b 0
)

where py >nul 2>nul
if %errorlevel%==0 (
    py build_launcher.py
    exit /b %errorlevel%
)

where python >nul 2>nul
if %errorlevel%==0 (
    python build_launcher.py
    exit /b %errorlevel%
)

mshta "javascript:alert('Python 3.11 or newer was not found. Install Python, then run build.bat again.');close();"
exit /b 1
