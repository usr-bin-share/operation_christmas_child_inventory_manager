#define MyAppName "OCC Inventory Manager"
#define MyAppVersion "1.4.3"
#define MyAppPublisher "usr-bin-share"
#define MyAppExeName "OCC Inventory Manager.exe"

[Setup]
AppId={{C6A1E910-43A5-4D45-8DC0-A81D8F877326}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DisableDirPage=no
UsePreviousAppDir=yes
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputBaseFilename=OCC_Inventory_Manager_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}
Uninstallable=yes
CreateUninstallRegKey=yes
LicenseFile=LICENSE
SetupLogging=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "OCC Inventory Manager.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "uninstall.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\{#MyAppName}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"
Name: "{autoprograms}\{#MyAppName}\Uninstall {#MyAppName}"; Filename: "{app}\uninstall.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent


[UninstallDelete]
Type: filesandordirs; Name: "{localappdata}\OCC Inventory Manager"

[Code]
function HasPurgeDataParameter: Boolean;
var
  I: Integer;
begin
  Result := False;
  for I := 1 to ParamCount do
  begin
    if CompareText(ParamStr(I), '/PURGEDATA') = 0 then
    begin
      Result := True;
      Exit;
    end;
  end;
end;

function InitializeUninstall(): Boolean;
var
  ConfirmText: String;
begin
  if HasPurgeDataParameter then
  begin
    Result := True;
    Exit;
  end;

  ConfirmText :=
    'This will permanently remove OCC Inventory Manager and delete all ' +
    'inventory data, transaction history, settings, and local backups ' +
    'stored in the application''s LocalAppData folder.' + #13#10 + #13#10 +
    'This action cannot be undone. Continue?';

  Result := MsgBox(ConfirmText, mbConfirmation, MB_YESNO) = IDYES;
end;


procedure ApplyOCCWizardColors;
begin
  { OCC Inventory Manager palette }
  WizardForm.Color := $00FAF6F3;              { #F3F6FA }
  WizardForm.MainPanel.Color := $003D2114;    { #14213D }
  WizardForm.InnerPage.Color := $00FAF6F3;    { #F3F6FA }
  WizardForm.PageNameLabel.Font.Color := clWhite;
  WizardForm.PageDescriptionLabel.Font.Color := $00DAC5B8; { #B8C5DA }
  WizardForm.WelcomeLabel1.Font.Color := $003D2114;        { #14213D }
  WizardForm.WelcomeLabel2.Font.Color := $008B7464;        { #64748B }
  WizardForm.FinishedHeadingLabel.Font.Color := $003D2114;
  WizardForm.FinishedLabel.Font.Color := $008B7464;
  WizardForm.SelectDirBrowseLabel.Font.Color := $003D2114;
  WizardForm.SelectStartMenuFolderBrowseLabel.Font.Color := $003D2114;
  WizardForm.TasksList.Color := clWhite;
  WizardForm.ReadyMemo.Color := clWhite;
  WizardForm.LicenseMemo.Color := clWhite;
end;

procedure InitializeWizard;
begin
  ApplyOCCWizardColors;
end;
