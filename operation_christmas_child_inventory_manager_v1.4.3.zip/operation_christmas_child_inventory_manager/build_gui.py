"""
One-click graphical Windows builder for OCC Inventory Manager.

The builder uses the installed Python interpreter directly, builds the
standalone application executable, and then compiles the Inno Setup installer.
"""

from __future__ import annotations

import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import traceback
import urllib.request
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


PROJECT_DIR = Path(__file__).resolve().parent
APP_NAME = "OCC Inventory Manager"
APP_EXE = PROJECT_DIR / f"{APP_NAME}.exe"
ISS_FILE = PROJECT_DIR / "OCC_Inventory_Manager.iss"
REQUIREMENTS_FILE = PROJECT_DIR / "requirements.txt"
BUILD_LOG = PROJECT_DIR / "build_error.log"
CONFIG_FILE = PROJECT_DIR / "builder_config.json"
DEFAULT_INSTALLER_OUTPUT = PROJECT_DIR
TOOLS_DIR = PROJECT_DIR / "tools"
PRIVATE_INNO_DIR = TOOLS_DIR / "inno"
PRIVATE_ISCC = PRIVATE_INNO_DIR / "ISCC.exe"
INNO_DOWNLOAD_URL = "https://jrsoftware.org/download.php/is.exe?dontcount=1"
INNO_INSTALLER_CACHE = TOOLS_DIR / "innosetup-latest.exe"
UNINSTALL_SOURCE = PROJECT_DIR / "uninstall_launcher.py"
UNINSTALL_EXE = PROJECT_DIR / "uninstall.exe"


def console_python() -> Path:
    """Return python.exe even when this script was launched with pythonw.exe."""
    executable = Path(sys.executable)
    if executable.name.lower() == "pythonw.exe":
        candidate = executable.with_name("python.exe")
        if candidate.exists():
            return candidate
    return executable


PYTHON_EXE = console_python()


class BuildWindow:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("OCC Inventory Manager Builder")
        self.root.geometry("820x660")
        self.root.minsize(740, 590)
        self.root.report_callback_exception = self.handle_tk_exception
        self.apply_occ_theme()

        self.messages = queue.Queue()
        self.is_building = False
        self.config = self.load_config()

        outer = ttk.Frame(root, padding=24)
        outer.pack(fill="both", expand=True)

        ttk.Label(
            outer,
            text="Build OCC Inventory Manager",
            font=("Segoe UI", 18, "bold"),
        ).pack(anchor="w")

        ttk.Label(
            outer,
            text="Build the application and Windows installer in one operation.",
            wraplength=700,
        ).pack(anchor="w", pady=(4, 18))

        ttk.Label(
            outer,
            text="Installer output folder",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w")

        folder_row = ttk.Frame(outer)
        folder_row.pack(fill="x", pady=(6, 14))

        self.output_var = tk.StringVar(value=self.config.get("installer_output_folder", str(DEFAULT_INSTALLER_OUTPUT)))
        self.output_entry = ttk.Entry(folder_row, textvariable=self.output_var)
        self.output_entry.pack(side="left", fill="x", expand=True)

        self.browse_output_button = ttk.Button(
            folder_row,
            text="Browse…",
            command=self.choose_output,
        )
        self.browse_output_button.pack(side="left", padx=(8, 0))

        ttk.Label(
            outer,
            text="Inno Setup compiler (automatically provided when needed)",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w")

        iscc_row = ttk.Frame(outer)
        iscc_row.pack(fill="x", pady=(6, 14))

        self.iscc_var = tk.StringVar(value=self.config.get("iscc_path", ""))
        self.iscc_entry = ttk.Entry(iscc_row, textvariable=self.iscc_var)
        self.iscc_entry.pack(side="left", fill="x", expand=True)

        self.detect_button = ttk.Button(
            iscc_row, text="Auto Detect", command=self.detect_inno_from_ui
        )
        self.detect_button.pack(side="left", padx=(8, 0))

        self.browse_iscc_button = ttk.Button(
            iscc_row, text="Browse…", command=self.choose_iscc
        )
        self.browse_iscc_button.pack(side="left", padx=(8, 0))

        self.progress = ttk.Progressbar(outer, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(2, 8))

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(outer, textvariable=self.status_var).pack(anchor="w", pady=(0, 10))

        ttk.Label(
            outer,
            text="Build activity",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w")

        log_frame = ttk.Frame(outer)
        log_frame.pack(fill="both", expand=True, pady=(6, 14))

        self.log = tk.Text(
            log_frame,
            wrap="word",
            state="disabled",
            font=("Consolas", 9),
            background="white",
            foreground="#1f2937",
            insertbackground="#14213d",
            selectbackground="#fca311",
            selectforeground="#14213d",
            relief="flat",
            highlightthickness=1,
            highlightbackground="#e1e7ef",
            highlightcolor="#fca311",
        )
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        self.log.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        buttons = ttk.Frame(outer)
        buttons.pack(fill="x")

        self.start_button = ttk.Button(
            buttons,
            text="Build Application and Installer",
            command=self.start_build,
            style="Accent.TButton",
        )
        self.start_button.pack(side="right")

        ttk.Button(buttons, text="Close", command=self.root.destroy).pack(
            side="right", padx=(0, 8)
        )

        self.append_log(f"Python: {PYTHON_EXE}")
        self.append_log("Ready to build.")
        self.root.after(100, self.process_messages)

    def apply_occ_theme(self) -> None:
        """Apply the same palette used by the PySide6 application."""
        self.root.configure(background="#f3f6fa")
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", font=("Segoe UI", 10), background="#f3f6fa", foreground="#1f2937")
        style.configure("TFrame", background="#f3f6fa")
        style.configure("TLabel", background="#f3f6fa", foreground="#1f2937")
        style.configure("TEntry", fieldbackground="white", foreground="#1f2937", bordercolor="#cbd5e1")
        style.configure("TButton", background="#14213d", foreground="white", borderwidth=0, padding=(12, 8))
        style.map("TButton", background=[("active", "#23395d"), ("disabled", "#94a3b8")], foreground=[("disabled", "#e2e8f0")])
        style.configure("Accent.TButton", background="#fca311", foreground="#14213d", borderwidth=0, padding=(14, 9))
        style.map("Accent.TButton", background=[("active", "#ffb52f"), ("disabled", "#94a3b8")])
        style.configure("Horizontal.TProgressbar", troughcolor="#e9eef5", background="#fca311", bordercolor="#e1e7ef", lightcolor="#fca311", darkcolor="#fca311")

    def load_config(self) -> dict:
        if not CONFIG_FILE.is_file():
            return {}
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def save_config(self) -> None:
        CONFIG_FILE.write_text(
            json.dumps(
                {
                    "installer_output_folder": self.output_var.get().strip(),
                    "iscc_path": self.iscc_var.get().strip(),
                },
                indent=2,
            ),
            encoding="utf-8",
        )

    def choose_iscc(self) -> None:
        current = self.iscc_var.get().strip()
        initial = str(Path(current).parent) if current else os.environ.get("ProgramFiles", str(PROJECT_DIR))
        selected = filedialog.askopenfilename(
            title="Select the Inno Setup compiler",
            initialdir=initial,
            filetypes=[
                ("Inno Setup Compiler", "ISCC.exe"),
                ("Executable files", "*.exe"),
                ("All files", "*.*"),
            ],
        )
        if not selected:
            return
        path = Path(selected)
        if path.name.lower() != "iscc.exe" or not path.is_file():
            messagebox.showerror("Invalid compiler", "Select the Inno Setup compiler file named ISCC.exe.")
            return
        self.iscc_var.set(str(path))
        self.save_config()
        self.append_log(f"Selected Inno Setup compiler: {path}")
        self.append_log(f"Using Inno Setup {self.get_inno_version(path)}")

    def detect_inno_from_ui(self) -> None:
        try:
            path = self.find_inno_compiler(ignore_config=True)
            self.iscc_var.set(str(path))
            self.save_config()
            version = self.get_inno_version(path)
            self.append_log(f"Detected Inno Setup compiler: {path}")
            self.append_log(f"Using Inno Setup {version}")
            messagebox.showinfo("Inno Setup detected", f"Inno Setup {version} was detected.\\n\\n{path}")
        except Exception as exc:
            messagebox.showwarning(
                "Inno Setup not detected",
                f"{exc}\\n\\nUse Browse to select ISCC.exe manually.",
            )

    def get_inno_version(self, iscc: Path) -> str:
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        result = subprocess.run(
            [str(iscc), "/?"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags,
            timeout=15,
        )
        output = result.stdout or ""
        for pattern in (
            r"Inno Setup(?: Compiler)?\\s+version\\s+([0-9]+(?:\\.[0-9]+){1,3})",
            r"Inno Setup\\s+([0-9]+(?:\\.[0-9]+){1,3})",
        ):
            match = re.search(pattern, output, flags=re.IGNORECASE)
            if match:
                return match.group(1)
        match = re.search(r"Inno Setup\\s*([0-9]+(?:\\.[0-9]+){0,3})", str(iscc.parent), re.IGNORECASE)
        return match.group(1) if match else "version unknown"

    def handle_tk_exception(self, exc_type, exc_value, exc_traceback) -> None:
        details = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        self.write_error_log(details)
        messagebox.showerror(
            "Builder error",
            f"An unexpected builder error occurred.\n\n{exc_value}\n\n"
            f"Details were saved to:\n{BUILD_LOG}",
        )

    def write_error_log(self, details: str) -> None:
        timestamp = datetime.now().isoformat(timespec="seconds")
        BUILD_LOG.write_text(
            f"OCC Inventory Manager build error\n"
            f"Time: {timestamp}\n"
            f"Python: {PYTHON_EXE}\n\n{details}",
            encoding="utf-8",
        )

    def choose_output(self) -> None:
        selected = filedialog.askdirectory(
            title="Choose installer output folder",
            initialdir=self.output_var.get() or str(PROJECT_DIR),
        )
        if selected:
            self.output_var.set(selected)
            self.save_config()

    def append_log(self, text: str) -> None:
        self.save_config()

        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")
        self.root.update_idletasks()

    def set_controls_enabled(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        self.start_button.configure(state=state)
        self.output_entry.configure(state=state)
        self.browse_output_button.configure(state=state)
        self.iscc_entry.configure(state=state)
        self.detect_button.configure(state=state)
        self.browse_iscc_button.configure(state=state)

    def start_build(self) -> None:
        if self.is_building:
            return

        output_text = self.output_var.get().strip()
        if not output_text:
            messagebox.showwarning(
                "Output folder required",
                "Choose where the completed installer should be saved.",
            )
            return

        output = Path(output_text).expanduser()

        try:
            output.mkdir(parents=True, exist_ok=True)
            test_file = output / ".occ_write_test"
            test_file.write_text("test", encoding="utf-8")
            test_file.unlink()
        except OSError as exc:
            messagebox.showerror(
                "Output folder unavailable",
                f"The selected output folder is not writable.\n\n{exc}",
            )
            return

        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        self.append_log("Build requested.")
        self.append_log(f"Installer output: {output}")
        self.progress["value"] = 1
        self.status_var.set("Starting build…")
        self.is_building = True
        self.set_controls_enabled(False)

        worker = threading.Thread(
            target=self.run_build,
            args=(output,),
            daemon=True,
            name="occ-build-worker",
        )
        worker.start()

        self.root.after(500, lambda: self.verify_worker_started(worker))

    def verify_worker_started(self, worker: threading.Thread) -> None:
        if self.is_building and not worker.is_alive() and self.progress["value"] <= 1:
            self.finish_failure(
                "The build worker stopped before starting. "
                f"Review {BUILD_LOG} for details."
            )

    def emit_log(self, text: str) -> None:
        self.messages.put(("log", text))

    def emit_progress(self, value: int) -> None:
        self.messages.put(("progress", value))

    def emit_status(self, text: str) -> None:
        self.messages.put(("status", text))

    def process_messages(self) -> None:
        try:
            while True:
                kind, value = self.messages.get_nowait()
                if kind == "log":
                    self.append_log(str(value))
                elif kind == "progress":
                    self.progress["value"] = int(value)
                elif kind == "status":
                    self.status_var.set(str(value))
                elif kind == "finished":
                    success, detail = value
                    if success:
                        self.finish_success(Path(detail))
                    else:
                        self.finish_failure(str(detail))
        except queue.Empty:
            pass
        finally:
            self.root.after(100, self.process_messages)

    def finish_success(self, output_folder: Path) -> None:
        self.is_building = False
        self.set_controls_enabled(True)
        self.status_var.set("Build complete")
        self.progress["value"] = 100
        if messagebox.askyesno(
            "Build complete",
            "The application and installer were created successfully.\n\n"
            "Open the installer output folder?",
        ):
            os.startfile(str(output_folder))

    def finish_failure(self, detail: str) -> None:
        self.is_building = False
        self.set_controls_enabled(True)
        self.status_var.set("Build failed")
        self.write_error_log(detail)
        messagebox.showerror(
            "Build failed",
            f"The build could not be completed.\n\n{detail}\n\n"
            f"Details were saved to:\n{BUILD_LOG}",
        )

    def run_command(self, command: list[str], cwd: Path) -> None:
        self.emit_log("> " + subprocess.list2cmdline(command))
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0

        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags,
        )

        if process.stdout is None:
            raise RuntimeError("The build process did not provide output.")

        output_lines: list[str] = []
        for line in process.stdout:
            clean_line = line.rstrip()
            output_lines.append(clean_line)
            self.emit_log(clean_line)

        return_code = process.wait()
        if return_code != 0:
            output_text = "\n".join(output_lines[-40:]).strip()
            detail = (f"\n\nCompiler output:\n{output_text}" if output_text else "")
            raise RuntimeError(
                f"Command failed with exit code {return_code}:\n"
                f"{subprocess.list2cmdline(command)}{detail}"
            )

    def find_inno_compiler(self, ignore_config: bool = False) -> Path:
        candidates: list[Path] = []

        if PRIVATE_ISCC.is_file():
            return PRIVATE_ISCC

        if not ignore_config:
            configured = self.iscc_var.get().strip()
            if configured:
                path = Path(configured)
                if path.is_file() and path.name.lower() == "iscc.exe":
                    return path

        found = shutil.which("ISCC.exe")
        if found:
            candidates.append(Path(found))

        for base in filter(None, [
            os.environ.get("ProgramFiles"),
            os.environ.get("ProgramFiles(x86)")
        ]):
            base = Path(base)
            for folder in base.glob("Inno Setup*"):
                iscc = folder / "ISCC.exe"
                if iscc.exists():
                    candidates.append(iscc)

        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            programs = Path(local_app_data) / "Programs"
            if programs.is_dir():
                for folder in programs.glob("Inno Setup*"):
                    iscc = folder / "ISCC.exe"
                    if iscc.exists():
                        candidates.append(iscc)

        unique = []
        seen = set()
        for candidate in candidates:
            key = str(candidate.resolve()).lower()
            if key not in seen:
                seen.add(key)
                unique.append(candidate)

        if not unique:
            raise RuntimeError("No installed Inno Setup compiler was detected.")

        def version_key(path: Path):
            version = self.get_inno_version(path)
            numbers = tuple(int(n) for n in re.findall(r"\\d+", version))
            return numbers or (0,)

        unique.sort(key=version_key, reverse=True)
        return unique[0]

    def provision_private_inno(self) -> Path:
        if PRIVATE_ISCC.is_file():
            return PRIVATE_ISCC

        TOOLS_DIR.mkdir(parents=True, exist_ok=True)
        PRIVATE_INNO_DIR.mkdir(parents=True, exist_ok=True)

        self.emit_status("Downloading the private Inno Setup compiler…")
        self.emit_log("No usable Inno Setup compiler was found.")
        self.emit_log("Downloading Inno Setup from the official JRSoftware website…")

        try:
            request = urllib.request.Request(
                INNO_DOWNLOAD_URL,
                headers={"User-Agent": "OCC-Inventory-Manager-Builder/1.4.3"},
            )
            with urllib.request.urlopen(request, timeout=120) as response:
                with INNO_INSTALLER_CACHE.open("wb") as destination:
                    shutil.copyfileobj(response, destination)
        except Exception as exc:
            raise RuntimeError(
                "The builder could not download the private Inno Setup compiler. "
                "Check the internet connection and try again.\n\n"
                f"Download source: {INNO_DOWNLOAD_URL}\nError: {exc}"
            ) from exc

        if not INNO_INSTALLER_CACHE.is_file() or INNO_INSTALLER_CACHE.stat().st_size < 1_000_000:
            raise RuntimeError("The downloaded Inno Setup installer is missing or incomplete.")

        self.emit_status("Preparing the private Inno Setup compiler…")
        self.emit_log(f"Preparing private compiler in: {PRIVATE_INNO_DIR}")
        self.run_command(
            [
                str(INNO_INSTALLER_CACHE),
                "/VERYSILENT",
                "/SUPPRESSMSGBOXES",
                "/NORESTART",
                "/SP-",
                "/NOICONS",
                "/CURRENTUSER",
                f"/DIR={PRIVATE_INNO_DIR}",
            ],
            PROJECT_DIR,
        )

        if not PRIVATE_ISCC.is_file():
            raise RuntimeError(
                "Inno Setup finished preparing, but ISCC.exe was not found at:\n"
                f"{PRIVATE_ISCC}"
            )

        self.iscc_var.set(str(PRIVATE_ISCC))
        self.save_config()
        return PRIVATE_ISCC

    def run_build(self, installer_output: Path) -> None:
        try:
            self.emit_status("Checking project files…")
            self.emit_log("Step 1 of 7: Checking project files…")
            self.emit_progress(8)

            required = [
                PROJECT_DIR / "main.py",
                REQUIREMENTS_FILE,
                ISS_FILE,
                UNINSTALL_SOURCE,
            ]
            missing = [str(path.name) for path in required if not path.is_file()]
            if missing:
                raise RuntimeError(
                    "Required project files are missing: " + ", ".join(missing)
                )

            self.emit_status("Installing build requirements…")
            self.emit_log("")
            self.emit_log("Step 2 of 7: Installing project requirements…")
            self.emit_progress(20)
            self.run_command(
                [str(PYTHON_EXE), "-m", "pip", "install", "--upgrade", "pip"],
                PROJECT_DIR,
            )
            self.run_command(
                [
                    str(PYTHON_EXE),
                    "-m",
                    "pip",
                    "install",
                    "-r",
                    str(REQUIREMENTS_FILE),
                ],
                PROJECT_DIR,
            )

            self.emit_status("Preparing application build…")
            self.emit_log("")
            self.emit_log("Step 3 of 7: Preparing the application build…")
            self.emit_progress(38)

            build_dir = PROJECT_DIR / "build"
            spec_file = PROJECT_DIR / f"{APP_NAME}.spec"

            if build_dir.exists():
                shutil.rmtree(build_dir, ignore_errors=True)
            if spec_file.exists():
                spec_file.unlink()
            if APP_EXE.exists():
                APP_EXE.unlink()
            if UNINSTALL_EXE.exists():
                UNINSTALL_EXE.unlink()

            self.emit_status("Building uninstall executable…")
            self.emit_log("")
            self.emit_log("Step 4 of 7: Building uninstall.exe…")
            self.emit_progress(46)
            self.run_command(
                [
                    str(PYTHON_EXE),
                    "-m",
                    "PyInstaller",
                    "--noconfirm",
                    "--clean",
                    "--windowed",
                    "--onefile",
                    "--name",
                    "uninstall",
                    "--distpath",
                    str(PROJECT_DIR),
                    "--workpath",
                    str(build_dir / "uninstall"),
                    "--specpath",
                    str(PROJECT_DIR),
                    str(UNINSTALL_SOURCE),
                ],
                PROJECT_DIR,
            )

            if not UNINSTALL_EXE.is_file():
                raise RuntimeError("PyInstaller did not create uninstall.exe.")

            self.emit_status("Building application executable…")
            self.emit_log("")
            self.emit_log("Step 5 of 7: Building the standalone executable…")
            self.emit_progress(58)
            self.run_command(
                [
                    str(PYTHON_EXE),
                    "-m",
                    "PyInstaller",
                    "--noconfirm",
                    "--clean",
                    "--windowed",
                    "--onefile",
                    "--name",
                    APP_NAME,
                    "--distpath",
                    str(PROJECT_DIR),
                    "--workpath",
                    str(build_dir / "application"),
                    "--specpath",
                    str(PROJECT_DIR),
                    "--collect-all",
                    "PySide6",
                    str(PROJECT_DIR / "main.py"),
                ],
                PROJECT_DIR,
            )

            if not APP_EXE.is_file():
                raise RuntimeError(
                    "PyInstaller completed, but OCC Inventory Manager.exe "
                    "was not created in the project folder."
                )

            self.emit_status("Locating Inno Setup…")
            self.emit_log("")
            self.emit_log("Step 6 of 7: Preparing Inno Setup compiler…")
            self.emit_progress(79)
            try:
                iscc = self.find_inno_compiler()
            except RuntimeError:
                iscc = self.provision_private_inno()
            version = self.get_inno_version(iscc)
            self.iscc_var.set(str(iscc))
            self.save_config()
            self.emit_log(f"Inno Setup compiler: {iscc}")
            self.emit_log(f"Using Inno Setup {version}")

            self.emit_status("Compiling installer…")
            self.emit_log("")
            self.emit_log("Step 7 of 7: Compiling the Windows installer…")
            self.emit_progress(90)
            self.run_command(
                [
                    str(iscc),
                    f"/O{installer_output}",
                    str(ISS_FILE),
                ],
                PROJECT_DIR,
            )

            installer = installer_output / "OCC_Inventory_Manager_Setup.exe"
            if not installer.is_file():
                raise RuntimeError(
                    "Inno Setup completed, but the installer was not found at:\n"
                    f"{installer}"
                )

            self.emit_log("")
            self.emit_log("Build completed successfully.")
            self.emit_log(f"Application: {APP_EXE}")
            self.emit_log(f"Uninstaller launcher: {UNINSTALL_EXE}")
            self.emit_log(f"Installer: {installer}")
            self.messages.put(("finished", (True, str(installer_output))))

        except Exception:
            details = traceback.format_exc()
            self.write_error_log(details)
            self.emit_log("")
            self.emit_log(details)
            self.messages.put(("finished", (False, details)))


def main() -> int:
    root = tk.Tk()
    BuildWindow(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
