from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QStandardPaths


def app_data_dir() -> Path:
    base = QStandardPaths.writableLocation(
        QStandardPaths.StandardLocation.AppLocalDataLocation
    )
    path = Path(base)
    path.mkdir(parents=True, exist_ok=True)
    return path


def database_path() -> Path:
    return app_data_dir() / "occ_inventory.db"
