from __future__ import annotations

import shutil

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .database import Database, DatabaseError
from .dialogs import AdjustmentDialog, ItemDialog
from .importer import import_inventory
from .reports import export_csv, export_pdf
from .widgets import StatCard


def create_page_header(title: str, subtitle: str) -> QVBoxLayout:
    layout = QVBoxLayout()
    title_label = QLabel(title)
    title_label.setObjectName("PageTitle")
    subtitle_label = QLabel(subtitle)
    subtitle_label.setObjectName("PageSubtitle")
    layout.addWidget(title_label)
    layout.addWidget(subtitle_label)
    return layout


class DashboardPage(QWidget):
    low_stock_requested = Signal()

    def __init__(self, database: Database):
        super().__init__()
        self.database = database

        self.items_card = StatCard("INVENTORY ITEM TYPES")
        self.quantity_card = StatCard("TOTAL QUANTITY")
        self.low_card = StatCard("LOW-STOCK ITEMS")
        self.category_card = StatCard("CATEGORIES")
        self.subcategory_card = StatCard("SUB-CATEGORIES")

        cards = QGridLayout()
        cards.setSpacing(14)
        cards.addWidget(self.items_card, 0, 0)
        cards.addWidget(self.quantity_card, 0, 1)
        cards.addWidget(self.low_card, 0, 2)
        cards.addWidget(self.category_card, 1, 0)
        cards.addWidget(self.subcategory_card, 1, 1)

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(
            ["Item", "Category", "Sub-category", "Qty", "Minimum"]
        )
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setStretchLastSection(True)

        view_button = QPushButton("View all low stock")
        view_button.setObjectName("AccentButton")
        view_button.clicked.connect(self.low_stock_requested.emit)

        table_header = QHBoxLayout()
        table_header.addWidget(QLabel("Items needing attention"))
        table_header.addStretch()
        table_header.addWidget(view_button)

        card = QFrame()
        card.setObjectName("Card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(16, 16, 16, 16)
        card_layout.addLayout(table_header)
        card_layout.addWidget(self.table)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 24)
        layout.setSpacing(18)
        layout.addLayout(create_page_header(
            "Dashboard",
            "A quick view of donated Operation Christmas Child supplies.",
        ))
        layout.addLayout(cards)
        layout.addWidget(card, 1)

    def refresh(self) -> None:
        stats = self.database.dashboard_stats()
        self.items_card.set_value(stats["item_count"])
        self.quantity_card.set_value(stats["total_quantity"])
        self.low_card.set_value(stats["low_stock_count"])
        self.category_card.set_value(stats["category_count"])
        self.subcategory_card.set_value(stats["subcategory_count"])

        rows = self.database.list_items(low_stock_only=True)[:10]
        self.table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            values = [
                row["name"],
                row["category_name"],
                row["subcategory_name"] or "",
                row["quantity_on_hand"],
                row["minimum_needed"],
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if column in (3, 4):
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(row_index, column, item)
        self.table.resizeColumnsToContents()


class InventoryPage(QWidget):
    changed = Signal()

    def __init__(self, database: Database):
        super().__init__()
        self.database = database
        self.low_stock_only = False

        self.search = QLineEdit()
        self.search.setPlaceholderText(
            "Search items, categories, sub-categories, or notes..."
        )
        self.search.textChanged.connect(self.refresh)

        self.table = QTableWidget()
        self.table.setColumnCount(9)
        self.table.setHorizontalHeaderLabels([
            "ID", "Item", "Category", "Sub-category",
            "Qty", "Minimum", "Age", "Gender", "Status"
        ])
        self.table.setColumnHidden(0, True)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSortingEnabled(True)
        self.table.doubleClicked.connect(self.edit_item)
        self.table.horizontalHeader().setStretchLastSection(True)

        add_button = QPushButton("Add item")
        add_button.setObjectName("AccentButton")
        add_button.clicked.connect(self.add_item)

        edit_button = QPushButton("Edit")
        edit_button.clicked.connect(self.edit_item)

        adjust_button = QPushButton("Adjust quantity")
        adjust_button.clicked.connect(self.adjust_quantity)

        import_button = QPushButton("Import Excel/CSV")
        import_button.clicked.connect(self.import_file)

        delete_button = QPushButton("Delete")
        delete_button.setObjectName("DangerButton")
        delete_button.clicked.connect(self.delete_item)

        toolbar = QHBoxLayout()
        toolbar.addWidget(self.search, 1)
        toolbar.addWidget(add_button)
        toolbar.addWidget(edit_button)
        toolbar.addWidget(adjust_button)
        toolbar.addWidget(import_button)
        toolbar.addWidget(delete_button)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 24)
        layout.setSpacing(16)
        layout.addLayout(create_page_header(
            "Inventory",
            "Add, search, import, and adjust donated supplies.",
        ))
        layout.addLayout(toolbar)
        layout.addWidget(self.table, 1)

    def selected_id(self) -> int | None:
        row = self.table.currentRow()
        if row < 0:
            return None
        item = self.table.item(row, 0)
        return int(item.text()) if item else None

    def set_low_stock_only(self, enabled: bool) -> None:
        self.low_stock_only = enabled
        self.refresh()

    def refresh(self) -> None:
        self.table.setSortingEnabled(False)
        rows = self.database.list_items(
            self.search.text(),
            self.low_stock_only,
        )
        self.table.setRowCount(len(rows))

        for row_index, row in enumerate(rows):
            low = row["quantity_on_hand"] <= row["minimum_needed"]
            values = [
                row["id"],
                row["name"],
                row["category_name"],
                row["subcategory_name"] or "",
                row["quantity_on_hand"],
                row["minimum_needed"],
                row["age_group"],
                row["gender"],
                "Low stock" if low else "In stock",
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if column in (4, 5):
                    item.setData(Qt.ItemDataRole.EditRole, int(value))
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                if column == 8:
                    item.setForeground(
                        QColor("#b42318" if low else "#157347")
                    )
                self.table.setItem(row_index, column, item)

        self.table.resizeColumnsToContents()
        self.table.setSortingEnabled(True)

    def add_item(self) -> None:
        dialog = ItemDialog(self.database, parent=self)
        if not dialog.exec():
            return
        try:
            self.database.save_item(item_id=None, **dialog.values())
        except DatabaseError as exc:
            QMessageBox.warning(self, "Could not save item", str(exc))
            return
        self.refresh()
        self.changed.emit()

    def edit_item(self) -> None:
        item_id = self.selected_id()
        if item_id is None:
            QMessageBox.information(self, "Select an item", "Select an item first.")
            return
        item = self.database.item(item_id)
        dialog = ItemDialog(self.database, item, self)
        if not dialog.exec():
            return
        try:
            self.database.save_item(item_id=item_id, **dialog.values())
        except DatabaseError as exc:
            QMessageBox.warning(self, "Could not save item", str(exc))
            return
        self.refresh()
        self.changed.emit()

    def adjust_quantity(self) -> None:
        item_id = self.selected_id()
        if item_id is None:
            QMessageBox.information(self, "Select an item", "Select an item first.")
            return
        dialog = AdjustmentDialog(self)
        if not dialog.exec():
            return
        amount, reason, notes = dialog.values()
        if amount == 0:
            return
        try:
            self.database.adjust_quantity(item_id, amount, reason, notes)
        except DatabaseError as exc:
            QMessageBox.warning(self, "Could not adjust quantity", str(exc))
            return
        self.refresh()
        self.changed.emit()

    def delete_item(self) -> None:
        item_id = self.selected_id()
        if item_id is None:
            QMessageBox.information(self, "Select an item", "Select an item first.")
            return
        answer = QMessageBox.question(
            self,
            "Delete item",
            "Permanently delete the selected item and its history?",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.database.delete_item(item_id)
        self.refresh()
        self.changed.emit()

    def import_file(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Import inventory",
            "",
            "Inventory files (*.xlsx *.csv)",
        )
        if not filename:
            return
        try:
            result = import_inventory(self.database, filename)
        except Exception as exc:
            QMessageBox.critical(self, "Import failed", str(exc))
            return
        self.refresh()
        self.changed.emit()
        QMessageBox.information(
            self,
            "Import complete",
            (
                f"Rows found: {result['rows']}\n"
                f"New items: {result['imported']}\n"
                f"Merged duplicates: {result['merged']}\n"
                f"Skipped rows: {result['skipped']}"
            ),
        )


class ReportsPage(QWidget):
    def __init__(self, database: Database):
        super().__init__()
        self.database = database
        self.low_stock_only = True

        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "Item", "Category", "Sub-category",
            "Qty", "Minimum", "Age", "Gender"
        ])
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)

        low_button = QPushButton("Low-stock report")
        low_button.setObjectName("AccentButton")
        low_button.clicked.connect(lambda: self.refresh(True))

        full_button = QPushButton("Full inventory")
        full_button.clicked.connect(lambda: self.refresh(False))

        csv_button = QPushButton("Export CSV")
        csv_button.clicked.connect(self.export_current_csv)

        pdf_button = QPushButton("Export PDF")
        pdf_button.clicked.connect(self.export_current_pdf)

        toolbar = QHBoxLayout()
        toolbar.addWidget(low_button)
        toolbar.addWidget(full_button)
        toolbar.addStretch()
        toolbar.addWidget(csv_button)
        toolbar.addWidget(pdf_button)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 24)
        layout.setSpacing(16)
        layout.addLayout(create_page_header(
            "Reports",
            "Review low stock and export printable inventory reports.",
        ))
        layout.addLayout(toolbar)
        layout.addWidget(self.table, 1)

    def refresh(self, low_stock_only: bool | None = None) -> None:
        if low_stock_only is not None:
            self.low_stock_only = low_stock_only
        rows = self.database.list_items(low_stock_only=self.low_stock_only)
        self.table.setRowCount(len(rows))

        for row_index, row in enumerate(rows):
            values = [
                row["name"],
                row["category_name"],
                row["subcategory_name"] or "",
                row["quantity_on_hand"],
                row["minimum_needed"],
                row["age_group"],
                row["gender"],
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if column in (3, 4):
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(row_index, column, item)
        self.table.resizeColumnsToContents()

    def current_rows(self):
        return self.database.list_items(low_stock_only=self.low_stock_only)

    def export_current_csv(self) -> None:
        default = (
            "occ_low_stock.csv"
            if self.low_stock_only
            else "occ_full_inventory.csv"
        )
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Export CSV",
            default,
            "CSV files (*.csv)",
        )
        if not filename:
            return
        export_csv(self.current_rows(), filename)
        QMessageBox.information(self, "Export complete", "CSV report created.")

    def export_current_pdf(self) -> None:
        default = (
            "occ_low_stock.pdf"
            if self.low_stock_only
            else "occ_full_inventory.pdf"
        )
        title = (
            "OCC Low-Stock Report"
            if self.low_stock_only
            else "OCC Full Inventory Report"
        )
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Export PDF",
            default,
            "PDF files (*.pdf)",
        )
        if not filename:
            return
        export_pdf(self.current_rows(), filename, title)
        QMessageBox.information(self, "Export complete", "PDF report created.")


class SettingsPage(QWidget):
    changed = Signal()

    def __init__(self, database: Database):
        super().__init__()
        self.database = database

        self.category_table = QTableWidget()
        self.category_table.setColumnCount(2)
        self.category_table.setHorizontalHeaderLabels(["ID", "Category"])
        self.category_table.setColumnHidden(0, True)
        self.category_table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows
        )
        self.category_table.setEditTriggers(
            QTableWidget.EditTrigger.NoEditTriggers
        )

        self.subcategory_table = QTableWidget()
        self.subcategory_table.setColumnCount(3)
        self.subcategory_table.setHorizontalHeaderLabels(
            ["ID", "Category", "Sub-category"]
        )
        self.subcategory_table.setColumnHidden(0, True)
        self.subcategory_table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows
        )
        self.subcategory_table.setEditTriggers(
            QTableWidget.EditTrigger.NoEditTriggers
        )

        tabs = QTabWidget()
        tabs.addTab(self._category_tab(), "Categories")
        tabs.addTab(self._subcategory_tab(), "Sub-categories")
        tabs.addTab(self._backup_tab(), "Backup")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 24)
        layout.setSpacing(16)
        layout.addLayout(create_page_header(
            "Settings",
            "Manage classifications and protect your inventory database.",
        ))
        layout.addWidget(tabs, 1)

    def _category_tab(self) -> QWidget:
        widget = QWidget()
        add = QPushButton("Add category")
        add.setObjectName("AccentButton")
        rename = QPushButton("Rename")
        delete = QPushButton("Delete")
        delete.setObjectName("DangerButton")

        add.clicked.connect(self.add_category)
        rename.clicked.connect(self.rename_category)
        delete.clicked.connect(self.delete_category)

        buttons = QHBoxLayout()
        buttons.addWidget(add)
        buttons.addWidget(rename)
        buttons.addWidget(delete)
        buttons.addStretch()

        layout = QVBoxLayout(widget)
        layout.addLayout(buttons)
        layout.addWidget(self.category_table)
        return widget

    def _subcategory_tab(self) -> QWidget:
        widget = QWidget()
        add = QPushButton("Add sub-category")
        add.setObjectName("AccentButton")
        rename = QPushButton("Rename")
        delete = QPushButton("Delete")
        delete.setObjectName("DangerButton")

        add.clicked.connect(self.add_subcategory)
        rename.clicked.connect(self.rename_subcategory)
        delete.clicked.connect(self.delete_subcategory)

        buttons = QHBoxLayout()
        buttons.addWidget(add)
        buttons.addWidget(rename)
        buttons.addWidget(delete)
        buttons.addStretch()

        layout = QVBoxLayout(widget)
        layout.addLayout(buttons)
        layout.addWidget(self.subcategory_table)
        return widget

    def _backup_tab(self) -> QWidget:
        widget = QWidget()
        label = QLabel(
            "Create a copy of the SQLite database and store it on another "
            "drive or in a secure cloud folder."
        )
        label.setWordWrap(True)

        button = QPushButton("Create database backup")
        button.setObjectName("AccentButton")
        button.clicked.connect(self.backup_database)

        layout = QVBoxLayout(widget)
        layout.addWidget(label)
        layout.addWidget(button, 0, Qt.AlignmentFlag.AlignLeft)
        layout.addStretch()
        return widget

    def refresh(self) -> None:
        categories = self.database.categories()
        self.category_table.setRowCount(len(categories))
        for row_index, row in enumerate(categories):
            self.category_table.setItem(
                row_index, 0, QTableWidgetItem(str(row["id"]))
            )
            self.category_table.setItem(
                row_index, 1, QTableWidgetItem(row["name"])
            )

        subcategories = self.database.subcategories()
        self.subcategory_table.setRowCount(len(subcategories))
        for row_index, row in enumerate(subcategories):
            self.subcategory_table.setItem(
                row_index, 0, QTableWidgetItem(str(row["id"]))
            )
            self.subcategory_table.setItem(
                row_index, 1, QTableWidgetItem(row["category_name"])
            )
            self.subcategory_table.setItem(
                row_index, 2, QTableWidgetItem(row["name"])
            )

        self.category_table.resizeColumnsToContents()
        self.subcategory_table.resizeColumnsToContents()

    @staticmethod
    def selected_id(table: QTableWidget) -> int | None:
        row = table.currentRow()
        if row < 0:
            return None
        return int(table.item(row, 0).text())

    def add_category(self) -> None:
        name, ok = QInputDialog.getText(
            self, "Add category", "Category name:"
        )
        if not ok:
            return
        try:
            self.database.add_category(name)
        except DatabaseError as exc:
            QMessageBox.warning(self, "Could not add category", str(exc))
            return
        self.refresh()
        self.changed.emit()

    def rename_category(self) -> None:
        category_id = self.selected_id(self.category_table)
        if category_id is None:
            QMessageBox.information(
                self, "Select category", "Select a category first."
            )
            return
        current = self.category_table.item(
            self.category_table.currentRow(), 1
        ).text()
        name, ok = QInputDialog.getText(
            self,
            "Rename category",
            "Category name:",
            text=current,
        )
        if not ok:
            return
        try:
            self.database.rename_category(category_id, name)
        except DatabaseError as exc:
            QMessageBox.warning(self, "Could not rename category", str(exc))
            return
        self.refresh()
        self.changed.emit()

    def delete_category(self) -> None:
        category_id = self.selected_id(self.category_table)
        if category_id is None:
            QMessageBox.information(
                self, "Select category", "Select a category first."
            )
            return
        try:
            self.database.delete_category(category_id)
        except DatabaseError as exc:
            QMessageBox.warning(self, "Could not delete category", str(exc))
            return
        self.refresh()
        self.changed.emit()

    def add_subcategory(self) -> None:
        categories = self.database.categories()
        names = [row["name"] for row in categories]
        category_name, ok = QInputDialog.getItem(
            self,
            "Choose category",
            "Parent category:",
            names,
            editable=False,
        )
        if not ok:
            return
        category_id = next(
            row["id"] for row in categories
            if row["name"] == category_name
        )
        name, ok = QInputDialog.getText(
            self,
            "Add sub-category",
            "Sub-category name:",
        )
        if not ok:
            return
        try:
            self.database.add_subcategory(category_id, name)
        except DatabaseError as exc:
            QMessageBox.warning(
                self, "Could not add sub-category", str(exc)
            )
            return
        self.refresh()
        self.changed.emit()

    def rename_subcategory(self) -> None:
        subcategory_id = self.selected_id(self.subcategory_table)
        if subcategory_id is None:
            QMessageBox.information(
                self,
                "Select sub-category",
                "Select a sub-category first.",
            )
            return
        current = self.subcategory_table.item(
            self.subcategory_table.currentRow(), 2
        ).text()
        name, ok = QInputDialog.getText(
            self,
            "Rename sub-category",
            "Sub-category name:",
            text=current,
        )
        if not ok:
            return
        try:
            self.database.rename_subcategory(subcategory_id, name)
        except DatabaseError as exc:
            QMessageBox.warning(
                self, "Could not rename sub-category", str(exc)
            )
            return
        self.refresh()
        self.changed.emit()

    def delete_subcategory(self) -> None:
        subcategory_id = self.selected_id(self.subcategory_table)
        if subcategory_id is None:
            QMessageBox.information(
                self,
                "Select sub-category",
                "Select a sub-category first.",
            )
            return
        try:
            self.database.delete_subcategory(subcategory_id)
        except DatabaseError as exc:
            QMessageBox.warning(
                self, "Could not delete sub-category", str(exc)
            )
            return
        self.refresh()
        self.changed.emit()

    def backup_database(self) -> None:
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Save database backup",
            "occ_inventory_backup.db",
            "SQLite database (*.db)",
        )
        if not filename:
            return
        try:
            self.database.connection.commit()
            shutil.copy2(self.database.path, filename)
        except OSError as exc:
            QMessageBox.critical(self, "Backup failed", str(exc))
            return
        QMessageBox.information(
            self,
            "Backup complete",
            "The inventory database was backed up successfully.",
        )
