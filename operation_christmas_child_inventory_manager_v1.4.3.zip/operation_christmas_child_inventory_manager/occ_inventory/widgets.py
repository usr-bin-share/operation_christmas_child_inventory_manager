from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout


class StatCard(QFrame):
    def __init__(self, caption: str):
        super().__init__()
        self.setObjectName("Card")
        self.setMinimumHeight(116)

        self.value = QLabel("0")
        self.value.setObjectName("CardValue")
        self.value.setAlignment(Qt.AlignmentFlag.AlignLeft)

        label = QLabel(caption)
        label.setObjectName("CardCaption")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 15, 18, 15)
        layout.addWidget(self.value)
        layout.addStretch()
        layout.addWidget(label)

    def set_value(self, value: int | str) -> None:
        self.value.setText(f"{value:,}" if isinstance(value, int) else str(value))
