from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QMessageBox,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
)

from .database import Database


class ItemDialog(QDialog):
    def __init__(self, database: Database, item=None, parent=None):
        super().__init__(parent)
        self.database = database
        self.item = item
        self.setWindowTitle("Edit Item" if item else "Add Item")
        self.setMinimumWidth(480)

        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("Example: Colored pencils")

        self.category_combo = QComboBox()
        self.subcategory_combo = QComboBox()

        self.quantity_spin = QSpinBox()
        self.quantity_spin.setRange(0, 999999)

        self.minimum_spin = QSpinBox()
        self.minimum_spin.setRange(0, 999999)

        self.age_combo = QComboBox()
        self.age_combo.addItems(["Any", "2-4", "5-9", "10-14"])

        self.gender_combo = QComboBox()
        self.gender_combo.addItems(["Any", "Boy", "Girl"])

        self.notes_edit = QTextEdit()
        self.notes_edit.setMaximumHeight(100)

        self._load_categories()
        self.category_combo.currentIndexChanged.connect(
            self._load_subcategories
        )

        form = QFormLayout()
        form.addRow("Item name", self.name_edit)
        form.addRow("Category", self.category_combo)
        form.addRow("Sub-category", self.subcategory_combo)
        form.addRow("Quantity on hand", self.quantity_spin)
        form.addRow("Minimum needed", self.minimum_spin)
        form.addRow("Age group", self.age_combo)
        form.addRow("Gender", self.gender_combo)
        form.addRow("Notes", self.notes_edit)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save
            | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._validate)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(buttons)

        if item:
            self._populate(item)
        else:
            self._load_subcategories()

    def _load_categories(self) -> None:
        self.category_combo.clear()
        for row in self.database.categories():
            self.category_combo.addItem(row["name"], row["id"])

    def _load_subcategories(self) -> None:
        wanted = self.subcategory_combo.currentData()
        self.subcategory_combo.clear()
        self.subcategory_combo.addItem("None", None)

        category_id = self.category_combo.currentData()
        if category_id is None:
            return

        for row in self.database.subcategories(category_id):
            self.subcategory_combo.addItem(row["name"], row["id"])

        index = self.subcategory_combo.findData(wanted)
        if index >= 0:
            self.subcategory_combo.setCurrentIndex(index)

    def _populate(self, item) -> None:
        self.name_edit.setText(item["name"])

        category_index = self.category_combo.findData(item["category_id"])
        if category_index >= 0:
            self.category_combo.setCurrentIndex(category_index)

        self._load_subcategories()
        subcategory_index = self.subcategory_combo.findData(
            item["subcategory_id"]
        )
        if subcategory_index >= 0:
            self.subcategory_combo.setCurrentIndex(subcategory_index)

        self.quantity_spin.setValue(item["quantity_on_hand"])
        self.minimum_spin.setValue(item["minimum_needed"])
        self.age_combo.setCurrentText(item["age_group"])
        self.gender_combo.setCurrentText(item["gender"])
        self.notes_edit.setPlainText(item["notes"])

    def _validate(self) -> None:
        if not self.name_edit.text().strip():
            QMessageBox.warning(self, "Missing item name", "Enter an item name.")
            return
        if self.category_combo.currentData() is None:
            QMessageBox.warning(self, "Missing category", "Select a category.")
            return
        self.accept()

    def values(self) -> dict:
        return {
            "name": self.name_edit.text().strip(),
            "category_id": self.category_combo.currentData(),
            "subcategory_id": self.subcategory_combo.currentData(),
            "quantity": self.quantity_spin.value(),
            "minimum": self.minimum_spin.value(),
            "age_group": self.age_combo.currentText(),
            "gender": self.gender_combo.currentText(),
            "notes": self.notes_edit.toPlainText().strip(),
        }


class AdjustmentDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Adjust Quantity")
        self.setMinimumWidth(390)

        self.amount = QSpinBox()
        self.amount.setRange(-999999, 999999)

        self.reason = QComboBox()
        self.reason.setEditable(True)
        self.reason.addItems(
            [
                "Donation received",
                "Items distributed",
                "Inventory correction",
                "Damaged items removed",
                "Other",
            ]
        )

        self.notes = QLineEdit()

        form = QFormLayout()
        form.addRow("Change amount", self.amount)
        form.addRow("Reason", self.reason)
        form.addRow("Notes", self.notes)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save
            | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def values(self):
        return (
            self.amount.value(),
            self.reason.currentText().strip() or "Adjustment",
            self.notes.text().strip(),
        )
