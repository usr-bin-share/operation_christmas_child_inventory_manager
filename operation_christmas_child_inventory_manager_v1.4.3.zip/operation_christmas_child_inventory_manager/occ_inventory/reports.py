from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import landscape, letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


def export_csv(rows, filename: str) -> None:
    with Path(filename).open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "Name",
                "Category",
                "Sub-category",
                "Quantity",
                "Minimum",
                "Age Group",
                "Gender",
                "Notes",
            ]
        )
        for row in rows:
            writer.writerow(
                [
                    row["name"],
                    row["category_name"],
                    row["subcategory_name"] or "",
                    row["quantity_on_hand"],
                    row["minimum_needed"],
                    row["age_group"],
                    row["gender"],
                    row["notes"],
                ]
            )


def export_pdf(rows, filename: str, title: str) -> None:
    styles = getSampleStyleSheet()
    document = SimpleDocTemplate(
        filename,
        pagesize=landscape(letter),
        leftMargin=28,
        rightMargin=28,
        topMargin=28,
        bottomMargin=28,
    )

    story = [
        Paragraph(title, styles["Title"]),
        Paragraph(
            f"Generated {datetime.now().strftime('%B %d, %Y at %I:%M %p')}",
            styles["Normal"],
        ),
        Spacer(1, 12),
    ]

    data = [[
        "Item", "Category", "Sub-category",
        "Qty", "Minimum", "Age", "Gender"
    ]]

    for row in rows:
        data.append([
            row["name"],
            row["category_name"],
            row["subcategory_name"] or "",
            str(row["quantity_on_hand"]),
            str(row["minimum_needed"]),
            row["age_group"],
            row["gender"],
        ])

    if len(data) == 1:
        story.append(Paragraph("No records found.", styles["Normal"]))
    else:
        table = Table(
            data,
            repeatRows=1,
            colWidths=[155, 105, 110, 45, 55, 60, 55],
        )
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#14213d")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#cbd5e1")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [
                colors.white,
                colors.HexColor("#f8fafc"),
            ]),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(table)

    document.build(story)
