from __future__ import annotations

import csv
from pathlib import Path

from openpyxl import load_workbook

from .database import Database


HEADER_ALIASES = {
    "name": {
        "name", "item", "item_name", "item_description",
        "description", "product", "supply"
    },
    "category": {"category", "category_name", "group"},
    "subcategory": {
        "subcategory", "sub_category", "sub-category",
        "subcategory_name", "type"
    },
    "quantity": {
        "quantity", "qty", "count", "amount",
        "quantity_on_hand", "qty_on_hand", "on_hand"
    },
    "minimum": {
        "minimum", "min", "minimum_needed",
        "minimum_quantity", "low_stock_level", "reorder_level"
    },
    "age_group": {"age_group", "age", "ages"},
    "gender": {"gender", "boy_girl", "recipient"},
    "notes": {"notes", "note", "comments", "comment"},
}


def normalize_header(value) -> str:
    return (
        str(value or "")
        .strip()
        .lower()
        .replace(" ", "_")
        .replace("/", "_")
    )


def canonical_header(value) -> str:
    normalized = normalize_header(value)
    for canonical, aliases in HEADER_ALIASES.items():
        if normalized in aliases:
            return canonical
    return normalized


def safe_int(value, default: int = 0) -> int:
    if value is None or str(value).strip() == "":
        return default
    try:
        return max(0, int(float(value)))
    except (TypeError, ValueError):
        return default


def find_header_row(rows: list[list[object]]) -> int:
    for index, row in enumerate(rows[:20]):
        headers = {canonical_header(value) for value in row}
        if "name" in headers:
            return index
    raise ValueError(
        "No item-name column was found. Use a heading such as "
        "Name, Item, Item Name, Description, or Item Description."
    )


def read_rows(path: Path) -> list[dict]:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        with path.open("r", newline="", encoding="utf-8-sig") as stream:
            raw_rows = list(csv.reader(stream))
    elif suffix == ".xlsx":
        workbook = load_workbook(path, data_only=True, read_only=True)
        worksheet = workbook.active
        raw_rows = [list(row) for row in worksheet.iter_rows(values_only=True)]
        workbook.close()
    else:
        raise ValueError("Select a CSV or XLSX file.")

    if not raw_rows:
        return []

    header_index = find_header_row(raw_rows)
    headers = [canonical_header(value) for value in raw_rows[header_index]]

    rows = []
    for raw_row in raw_rows[header_index + 1:]:
        if not any(value not in (None, "") for value in raw_row):
            continue
        rows.append(dict(zip(headers, raw_row)))
    return rows


def get_or_create_category(database: Database, name: str) -> int:
    clean_name = (name or "Other").strip() or "Other"
    for row in database.categories():
        if row["name"].casefold() == clean_name.casefold():
            return row["id"]
    database.add_category(clean_name)
    return next(
        row["id"]
        for row in database.categories()
        if row["name"].casefold() == clean_name.casefold()
    )


def get_or_create_subcategory(
    database: Database,
    category_id: int,
    name: str,
) -> int | None:
    clean_name = (name or "").strip()
    if not clean_name:
        return None

    for row in database.subcategories(category_id):
        if row["name"].casefold() == clean_name.casefold():
            return row["id"]

    database.add_subcategory(category_id, clean_name)
    return next(
        row["id"]
        for row in database.subcategories(category_id)
        if row["name"].casefold() == clean_name.casefold()
    )


def import_inventory(database: Database, filename: str) -> dict[str, int]:
    rows = read_rows(Path(filename))
    imported = 0
    merged = 0
    skipped = 0

    for row in rows:
        name = str(row.get("name") or "").strip()
        if not name:
            skipped += 1
            continue

        category_id = get_or_create_category(
            database,
            str(row.get("category") or "Other"),
        )
        subcategory_id = get_or_create_subcategory(
            database,
            category_id,
            str(row.get("subcategory") or ""),
        )

        quantity = safe_int(row.get("quantity"))
        minimum = safe_int(row.get("minimum"))
        age_group = str(row.get("age_group") or "Any").strip() or "Any"
        gender = str(row.get("gender") or "Any").strip().title() or "Any"
        notes = str(row.get("notes") or "").strip()

        duplicate = database.find_duplicate(
            name,
            category_id,
            subcategory_id,
        )

        if duplicate:
            if quantity:
                database.adjust_quantity(
                    duplicate["id"],
                    quantity,
                    "Imported quantity",
                    "CSV/XLSX import",
                )
            merged += 1
            continue

        database.save_item(
            item_id=None,
            name=name,
            category_id=category_id,
            subcategory_id=subcategory_id,
            quantity=quantity,
            minimum=minimum,
            age_group=age_group,
            gender=gender,
            notes=notes,
        )
        imported += 1

    return {
        "rows": len(rows),
        "imported": imported,
        "merged": merged,
        "skipped": skipped,
    }
