"""Operation Christmas Child Inventory Manager."""

__version__ = "1.0.0"
