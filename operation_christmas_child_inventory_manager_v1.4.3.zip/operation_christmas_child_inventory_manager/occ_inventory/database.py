from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path

from .paths import database_path


class DatabaseError(RuntimeError):
    """Base error for user-facing database problems."""


class DuplicateItemError(DatabaseError):
    """Raised when an item duplicates name/category/sub-category."""


class Database:
    def __init__(self, path: Path | None = None):
        self.path = Path(path or database_path())
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA foreign_keys = ON")
        self.connection.execute("PRAGMA journal_mode = WAL")
        self._create_schema()
        self._seed_defaults()

    def _create_schema(self) -> None:
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL COLLATE NOCASE UNIQUE
            );

            CREATE TABLE IF NOT EXISTS subcategories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_id INTEGER NOT NULL,
                name TEXT NOT NULL COLLATE NOCASE,
                UNIQUE(category_id, name),
                FOREIGN KEY(category_id)
                    REFERENCES categories(id)
                    ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category_id INTEGER NOT NULL,
                subcategory_id INTEGER,
                quantity_on_hand INTEGER NOT NULL DEFAULT 0
                    CHECK(quantity_on_hand >= 0),
                minimum_needed INTEGER NOT NULL DEFAULT 0
                    CHECK(minimum_needed >= 0),
                age_group TEXT NOT NULL DEFAULT 'Any',
                gender TEXT NOT NULL DEFAULT 'Any',
                notes TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL,
                FOREIGN KEY(category_id) REFERENCES categories(id),
                FOREIGN KEY(subcategory_id) REFERENCES subcategories(id)
            );

            CREATE TABLE IF NOT EXISTS inventory_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id INTEGER NOT NULL,
                change_amount INTEGER NOT NULL,
                reason TEXT NOT NULL,
                created_at TEXT NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                FOREIGN KEY(item_id)
                    REFERENCES items(id)
                    ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_items_name
                ON items(name);
            CREATE INDEX IF NOT EXISTS idx_items_category
                ON items(category_id);
            CREATE INDEX IF NOT EXISTS idx_items_subcategory
                ON items(subcategory_id);
            """
        )
        self.connection.commit()

    def _seed_defaults(self) -> None:
        defaults = {
            "Toys": ["Balls", "Cars", "Dolls", "Stuffed Animals", "Jump Ropes"],
            "School Supplies": ["Crayons", "Pencils", "Notebooks", "Erasers"],
            "Hygiene": ["Toothbrushes", "Washcloths", "Combs", "Soap"],
            "Clothing": ["Socks", "Shirts", "Hats", "Gloves"],
            "Accessories": ["Hair Accessories", "Jewelry", "Bags"],
            "Crafts": ["Stickers", "Beads", "Coloring Items"],
            "Other": ["General"],
        }
        cursor = self.connection.cursor()
        for category, subcategories in defaults.items():
            cursor.execute(
                "INSERT OR IGNORE INTO categories(name) VALUES (?)",
                (category,),
            )
            category_id = cursor.execute(
                "SELECT id FROM categories WHERE name = ?",
                (category,),
            ).fetchone()["id"]
            for subcategory in subcategories:
                cursor.execute(
                    """
                    INSERT OR IGNORE INTO subcategories(category_id, name)
                    VALUES (?, ?)
                    """,
                    (category_id, subcategory),
                )
        self.connection.commit()

    def categories(self):
        return self.connection.execute(
            "SELECT id, name FROM categories ORDER BY name COLLATE NOCASE"
        ).fetchall()

    def subcategories(self, category_id: int | None = None):
        if category_id is None:
            return self.connection.execute(
                """
                SELECT s.id, s.category_id, s.name,
                       c.name AS category_name
                FROM subcategories s
                JOIN categories c ON c.id = s.category_id
                ORDER BY c.name COLLATE NOCASE, s.name COLLATE NOCASE
                """
            ).fetchall()
        return self.connection.execute(
            """
            SELECT id, category_id, name
            FROM subcategories
            WHERE category_id = ?
            ORDER BY name COLLATE NOCASE
            """,
            (category_id,),
        ).fetchall()

    def add_category(self, name: str) -> None:
        name = name.strip()
        if not name:
            raise DatabaseError("Category name is required.")
        try:
            self.connection.execute(
                "INSERT INTO categories(name) VALUES (?)",
                (name,),
            )
            self.connection.commit()
        except sqlite3.IntegrityError as exc:
            raise DatabaseError("That category already exists.") from exc

    def rename_category(self, category_id: int, name: str) -> None:
        name = name.strip()
        if not name:
            raise DatabaseError("Category name is required.")
        try:
            self.connection.execute(
                "UPDATE categories SET name = ? WHERE id = ?",
                (name, category_id),
            )
            self.connection.commit()
        except sqlite3.IntegrityError as exc:
            raise DatabaseError("That category already exists.") from exc

    def delete_category(self, category_id: int) -> None:
        used = self.connection.execute(
            "SELECT COUNT(*) FROM items WHERE category_id = ?",
            (category_id,),
        ).fetchone()[0]
        if used:
            raise DatabaseError(
                "This category is assigned to inventory items and cannot be deleted."
            )
        self.connection.execute(
            "DELETE FROM categories WHERE id = ?",
            (category_id,),
        )
        self.connection.commit()

    def add_subcategory(self, category_id: int, name: str) -> None:
        name = name.strip()
        if not name:
            raise DatabaseError("Sub-category name is required.")
        try:
            self.connection.execute(
                """
                INSERT INTO subcategories(category_id, name)
                VALUES (?, ?)
                """,
                (category_id, name),
            )
            self.connection.commit()
        except sqlite3.IntegrityError as exc:
            raise DatabaseError(
                "That sub-category already exists under this category."
            ) from exc

    def rename_subcategory(self, subcategory_id: int, name: str) -> None:
        name = name.strip()
        if not name:
            raise DatabaseError("Sub-category name is required.")
        try:
            self.connection.execute(
                "UPDATE subcategories SET name = ? WHERE id = ?",
                (name, subcategory_id),
            )
            self.connection.commit()
        except sqlite3.IntegrityError as exc:
            raise DatabaseError(
                "That sub-category already exists under this category."
            ) from exc

    def delete_subcategory(self, subcategory_id: int) -> None:
        used = self.connection.execute(
            "SELECT COUNT(*) FROM items WHERE subcategory_id = ?",
            (subcategory_id,),
        ).fetchone()[0]
        if used:
            raise DatabaseError(
                "This sub-category is assigned to inventory items and cannot be deleted."
            )
        self.connection.execute(
            "DELETE FROM subcategories WHERE id = ?",
            (subcategory_id,),
        )
        self.connection.commit()

    def list_items(self, search: str = "", low_stock_only: bool = False):
        pattern = f"%{search.strip()}%"
        where = """
            WHERE (
                i.name LIKE ?
                OR c.name LIKE ?
                OR COALESCE(s.name, '') LIKE ?
                OR i.notes LIKE ?
            )
        """
        params: list[object] = [pattern, pattern, pattern, pattern]
        if low_stock_only:
            where += " AND i.quantity_on_hand <= i.minimum_needed"

        return self.connection.execute(
            f"""
            SELECT i.*, c.name AS category_name,
                   s.name AS subcategory_name
            FROM items i
            JOIN categories c ON c.id = i.category_id
            LEFT JOIN subcategories s ON s.id = i.subcategory_id
            {where}
            ORDER BY i.name COLLATE NOCASE
            """,
            params,
        ).fetchall()

    def item(self, item_id: int):
        return self.connection.execute(
            """
            SELECT i.*, c.name AS category_name,
                   s.name AS subcategory_name
            FROM items i
            JOIN categories c ON c.id = i.category_id
            LEFT JOIN subcategories s ON s.id = i.subcategory_id
            WHERE i.id = ?
            """,
            (item_id,),
        ).fetchone()

    def find_duplicate(
        self,
        name: str,
        category_id: int,
        subcategory_id: int | None,
        exclude_id: int | None = None,
    ):
        sql = """
            SELECT id
            FROM items
            WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))
              AND category_id = ?
              AND COALESCE(subcategory_id, 0) = COALESCE(?, 0)
        """
        params: list[object] = [name, category_id, subcategory_id]
        if exclude_id is not None:
            sql += " AND id <> ?"
            params.append(exclude_id)
        return self.connection.execute(sql, params).fetchone()

    def save_item(
        self,
        *,
        item_id: int | None,
        name: str,
        category_id: int,
        subcategory_id: int | None,
        quantity: int,
        minimum: int,
        age_group: str,
        gender: str,
        notes: str,
    ) -> int:
        name = name.strip()
        if not name:
            raise DatabaseError("Item name is required.")
        if quantity < 0 or minimum < 0:
            raise DatabaseError("Quantity and minimum cannot be negative.")
        if self.find_duplicate(name, category_id, subcategory_id, item_id):
            raise DuplicateItemError(
                "An item with the same name, category, and sub-category already exists."
            )

        now = datetime.now().isoformat(timespec="seconds")
        cursor = self.connection.cursor()

        if item_id is None:
            cursor.execute(
                """
                INSERT INTO items(
                    name, category_id, subcategory_id,
                    quantity_on_hand, minimum_needed,
                    age_group, gender, notes, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    name,
                    category_id,
                    subcategory_id,
                    quantity,
                    minimum,
                    age_group,
                    gender,
                    notes.strip(),
                    now,
                ),
            )
            item_id = int(cursor.lastrowid)
            if quantity:
                cursor.execute(
                    """
                    INSERT INTO inventory_transactions(
                        item_id, change_amount, reason, created_at, notes
                    )
                    VALUES (?, ?, 'Initial quantity', ?, '')
                    """,
                    (item_id, quantity, now),
                )
        else:
            old = cursor.execute(
                "SELECT quantity_on_hand FROM items WHERE id = ?",
                (item_id,),
            ).fetchone()
            if old is None:
                raise DatabaseError("The selected item no longer exists.")
            old_quantity = old["quantity_on_hand"]

            cursor.execute(
                """
                UPDATE items
                SET name = ?, category_id = ?, subcategory_id = ?,
                    quantity_on_hand = ?, minimum_needed = ?,
                    age_group = ?, gender = ?, notes = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    name,
                    category_id,
                    subcategory_id,
                    quantity,
                    minimum,
                    age_group,
                    gender,
                    notes.strip(),
                    now,
                    item_id,
                ),
            )
            change = quantity - old_quantity
            if change:
                cursor.execute(
                    """
                    INSERT INTO inventory_transactions(
                        item_id, change_amount, reason, created_at, notes
                    )
                    VALUES (?, ?, 'Item edited', ?, '')
                    """,
                    (item_id, change, now),
                )

        self.connection.commit()
        return int(item_id)

    def adjust_quantity(
        self,
        item_id: int,
        amount: int,
        reason: str,
        notes: str = "",
    ) -> None:
        row = self.connection.execute(
            "SELECT quantity_on_hand FROM items WHERE id = ?",
            (item_id,),
        ).fetchone()
        if row is None:
            raise DatabaseError("The selected item no longer exists.")

        new_quantity = row["quantity_on_hand"] + amount
        if new_quantity < 0:
            raise DatabaseError(
                "This adjustment would make the quantity negative."
            )

        now = datetime.now().isoformat(timespec="seconds")
        self.connection.execute(
            """
            UPDATE items
            SET quantity_on_hand = ?, updated_at = ?
            WHERE id = ?
            """,
            (new_quantity, now, item_id),
        )
        self.connection.execute(
            """
            INSERT INTO inventory_transactions(
                item_id, change_amount, reason, created_at, notes
            )
            VALUES (?, ?, ?, ?, ?)
            """,
            (item_id, amount, reason.strip() or "Adjustment", now, notes.strip()),
        )
        self.connection.commit()

    def delete_item(self, item_id: int) -> None:
        self.connection.execute(
            "DELETE FROM items WHERE id = ?",
            (item_id,),
        )
        self.connection.commit()

    def dashboard_stats(self) -> dict[str, int]:
        row = self.connection.execute(
            """
            SELECT
                COUNT(*) AS item_count,
                COALESCE(SUM(quantity_on_hand), 0) AS total_quantity,
                COALESCE(SUM(
                    CASE
                        WHEN quantity_on_hand <= minimum_needed THEN 1
                        ELSE 0
                    END
                ), 0) AS low_stock_count
            FROM items
            """
        ).fetchone()

        category_count = self.connection.execute(
            "SELECT COUNT(*) FROM categories"
        ).fetchone()[0]
        subcategory_count = self.connection.execute(
            "SELECT COUNT(*) FROM subcategories"
        ).fetchone()[0]

        return {
            "item_count": int(row["item_count"]),
            "total_quantity": int(row["total_quantity"]),
            "low_stock_count": int(row["low_stock_count"]),
            "category_count": int(category_count),
            "subcategory_count": int(subcategory_count),
        }

    def transactions(self, item_id: int, limit: int = 100):
        return self.connection.execute(
            """
            SELECT change_amount, reason, created_at, notes
            FROM inventory_transactions
            WHERE item_id = ?
            ORDER BY created_at DESC, id DESC
            LIMIT ?
            """,
            (item_id, limit),
        ).fetchall()

    def close(self) -> None:
        self.connection.close()
