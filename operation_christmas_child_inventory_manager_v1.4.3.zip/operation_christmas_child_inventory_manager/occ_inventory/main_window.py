from __future__ import annotations

from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from .database import Database
from .pages import DashboardPage, InventoryPage, ReportsPage, SettingsPage


class MainWindow(QMainWindow):
    def __init__(self, database: Database):
        super().__init__()
        self.database = database

        self.setWindowTitle("OCC Inventory Manager")
        self.resize(1280, 800)
        self.setMinimumSize(1050, 680)

        root = QWidget()
        root.setObjectName("AppRoot")
        root_layout = QHBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        self.stack = QStackedWidget()
        self.dashboard = DashboardPage(database)
        self.inventory = InventoryPage(database)
        self.reports = ReportsPage(database)
        self.settings = SettingsPage(database)

        self.stack.addWidget(self.dashboard)
        self.stack.addWidget(self.inventory)
        self.stack.addWidget(self.reports)
        self.stack.addWidget(self.settings)

        root_layout.addWidget(self._build_sidebar())
        root_layout.addWidget(self.stack, 1)
        self.setCentralWidget(root)

        self.dashboard.low_stock_requested.connect(self.show_low_stock)
        self.inventory.changed.connect(self.refresh_all)
        self.settings.changed.connect(self.refresh_all)

        self.statusBar().showMessage(
            f"Database: {self.database.path}"
        )
        self.refresh_all()

    def _build_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(225)

        title = QLabel("OCC Inventory")
        title.setObjectName("BrandTitle")

        subtitle = QLabel("Donation Manager")
        subtitle.setObjectName("BrandSubtitle")

        navigation = [
            ("Dashboard", 0),
            ("Inventory", 1),
            ("Reports", 2),
            ("Settings", 3),
        ]

        self.nav_buttons: list[QPushButton] = []
        nav_layout = QVBoxLayout()
        nav_layout.setSpacing(6)

        for label, index in navigation:
            button = QPushButton(label)
            button.setObjectName("NavButton")
            button.setCheckable(True)
            button.clicked.connect(
                lambda checked=False, page=index: self.navigate(page)
            )
            self.nav_buttons.append(button)
            nav_layout.addWidget(button)

        nav_layout.addStretch()

        footer = QLabel("GPL-3.0-or-later\nusr-bin-share")
        footer.setObjectName("BrandSubtitle")

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(18, 24, 18, 18)
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(28)
        layout.addLayout(nav_layout, 1)
        layout.addWidget(footer)

        self.nav_buttons[0].setChecked(True)
        return sidebar

    def navigate(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        for button_index, button in enumerate(self.nav_buttons):
            button.setChecked(button_index == index)

        if index == 0:
            self.dashboard.refresh()
        elif index == 1:
            self.inventory.set_low_stock_only(False)
        elif index == 2:
            self.reports.refresh()
        elif index == 3:
            self.settings.refresh()

    def show_low_stock(self) -> None:
        self.navigate(1)
        self.inventory.set_low_stock_only(True)

    def refresh_all(self) -> None:
        self.dashboard.refresh()
        self.inventory.refresh()
        self.reports.refresh()
        self.settings.refresh()

    def closeEvent(self, event) -> None:
        self.database.close()
        super().closeEvent(event)
