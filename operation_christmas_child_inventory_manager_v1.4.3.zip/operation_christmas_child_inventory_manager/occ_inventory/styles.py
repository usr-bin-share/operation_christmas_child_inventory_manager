APP_STYLE = """
QWidget {
    font-family: "Segoe UI";
    font-size: 10pt;
    color: #1f2937;
}

QMainWindow, QWidget#AppRoot {
    background: #f3f6fa;
}

QFrame#Sidebar {
    background: #14213d;
    border: none;
}

QLabel#BrandTitle {
    color: white;
    font-size: 17pt;
    font-weight: 700;
}

QLabel#BrandSubtitle {
    color: #b8c5da;
    font-size: 9pt;
}

QPushButton#NavButton {
    color: #dce6f5;
    background: transparent;
    border: none;
    border-radius: 8px;
    padding: 12px 14px;
    text-align: left;
    font-weight: 600;
}

QPushButton#NavButton:hover {
    background: #23395d;
    color: white;
}

QPushButton#NavButton:checked {
    background: #fca311;
    color: #14213d;
}

QLabel#PageTitle {
    color: #14213d;
    font-size: 22pt;
    font-weight: 700;
}

QLabel#PageSubtitle {
    color: #64748b;
}

QFrame#Card {
    background: white;
    border: 1px solid #e1e7ef;
    border-radius: 12px;
}

QLabel#CardValue {
    color: #14213d;
    font-size: 24pt;
    font-weight: 700;
}

QLabel#CardCaption {
    color: #64748b;
    font-size: 9pt;
    font-weight: 600;
}

QPushButton {
    background: #14213d;
    color: white;
    border: none;
    border-radius: 7px;
    padding: 8px 14px;
    font-weight: 600;
}

QPushButton:hover {
    background: #23395d;
}

QPushButton:disabled {
    background: #94a3b8;
    color: #e2e8f0;
}

QPushButton#AccentButton {
    background: #fca311;
    color: #14213d;
}

QPushButton#AccentButton:hover {
    background: #ffb52f;
}

QPushButton#DangerButton {
    background: #b42318;
}

QPushButton#DangerButton:hover {
    background: #d92d20;
}

QLineEdit, QComboBox, QSpinBox, QTextEdit {
    background: white;
    border: 1px solid #cbd5e1;
    border-radius: 7px;
    padding: 7px;
    selection-background-color: #fca311;
}

QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QTextEdit:focus {
    border: 1px solid #fca311;
}

QTableWidget {
    background: white;
    alternate-background-color: #f8fafc;
    border: 1px solid #e1e7ef;
    border-radius: 9px;
    gridline-color: #e2e8f0;
}

QHeaderView::section {
    background: #e9eef5;
    color: #334155;
    border: none;
    border-bottom: 1px solid #cbd5e1;
    padding: 9px;
    font-weight: 700;
}

QTableWidget::item {
    padding: 7px;
}

QTableWidget::item:selected {
    background: #dce8f7;
    color: #14213d;
}

QTabWidget::pane {
    border: 1px solid #e1e7ef;
    background: white;
    border-radius: 8px;
}

QTabBar::tab {
    background: #e9eef5;
    padding: 9px 16px;
    margin-right: 2px;
}

QTabBar::tab:selected {
    background: #fca311;
    color: #14213d;
}

QStatusBar {
    background: white;
    border-top: 1px solid #e1e7ef;
    color: #64748b;
}
"""
