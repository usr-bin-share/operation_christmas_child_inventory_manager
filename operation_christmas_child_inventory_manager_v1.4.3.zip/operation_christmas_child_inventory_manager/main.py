"""
Operation Christmas Child Inventory Manager
Author: usr-bin-share
License: GNU GPL v3.0 or later
"""

from __future__ import annotations

import sys

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QMessageBox

from occ_inventory.database import Database
from occ_inventory.main_window import MainWindow
from occ_inventory.styles import APP_STYLE


def main() -> int:
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName("OCC Inventory Manager")
    app.setOrganizationName("usr-bin-share")
    app.setStyle("Fusion")
    app.setStyleSheet(APP_STYLE)

    try:
        database = Database()
        window = MainWindow(database)
        window.show()
        return app.exec()
    except Exception as exc:
        QMessageBox.critical(
            None,
            "OCC Inventory Manager",
            f"The application could not start.\n\n{exc}",
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
