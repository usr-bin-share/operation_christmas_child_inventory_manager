"""OCC Inventory Manager uninstall launcher."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

APP_NAME = "OCC Inventory Manager"


def find_inno_uninstaller(app_dir: Path) -> Path | None:
    candidates = sorted(
        app_dir.glob("unins*.exe"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    for candidate in candidates:
        if candidate.name.lower() != "uninstall.exe":
            return candidate
    return None


def main() -> int:
    app_dir = Path(sys.executable).resolve().parent
    root = tk.Tk()
    root.withdraw()

    confirmed = messagebox.askyesno(
        f"Uninstall {APP_NAME}",
        "This will permanently remove OCC Inventory Manager and delete all "
        "inventory data, transaction history, settings, and local backups "
        "stored in the application's LocalAppData folder.\n\n"
        "This action cannot be undone. Continue?",
        icon="warning",
    )
    root.destroy()

    if not confirmed:
        return 0

    inno_uninstaller = find_inno_uninstaller(app_dir)
    if inno_uninstaller is None:
        error_root = tk.Tk()
        error_root.withdraw()
        messagebox.showerror(
            "Uninstaller not found",
            "The main application uninstaller could not be found. "
            "Reinstall OCC Inventory Manager, then try uninstalling again.",
        )
        error_root.destroy()
        return 1

    try:
        subprocess.Popen([str(inno_uninstaller), "/PURGEDATA"], cwd=str(app_dir))
    except OSError as exc:
        error_root = tk.Tk()
        error_root.withdraw()
        messagebox.showerror("Unable to start uninstaller", str(exc))
        error_root.destroy()
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
