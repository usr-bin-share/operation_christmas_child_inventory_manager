@echo off
setlocal
cd /d "%~dp0"

where pyw >nul 2>nul
if %errorlevel%==0 (
    start "" pyw -3 build_gui.py
    exit /b 0
)

where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw build_gui.py
    exit /b 0
)

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 build_gui.py
    exit /b %errorlevel%
)

where python >nul 2>nul
if %errorlevel%==0 (
    python build_gui.py
    exit /b %errorlevel%
)

mshta "javascript:alert('Python 3.11 or newer was not found. Install Python, then run build.bat again.');close();"
exit /b 1
