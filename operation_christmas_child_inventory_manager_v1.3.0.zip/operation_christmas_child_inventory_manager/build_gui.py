"""
One-click graphical Windows builder for OCC Inventory Manager.

Uses only the Python standard library for the builder interface.
It creates the application executable and then compiles the installer.
"""

from __future__ import annotations

import os
import queue
import shutil
import subprocess
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


PROJECT_DIR = Path(__file__).resolve().parent
VENV_DIR = PROJECT_DIR / ".venv"
APP_NAME = "OCC Inventory Manager"
APP_EXE = PROJECT_DIR / f"{APP_NAME}.exe"
ISS_FILE = PROJECT_DIR / "OCC_Inventory_Manager.iss"
DEFAULT_INSTALLER_OUTPUT = PROJECT_DIR


class BuildWindow:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("OCC Inventory Manager Builder")
        self.root.geometry("760x560")
        self.root.minsize(680, 500)

        self.messages: queue.Queue[tuple[str, object]] = queue.Queue()

        outer = ttk.Frame(root, padding=24)
        outer.pack(fill="both", expand=True)

        ttk.Label(
            outer,
            text="Build OCC Inventory Manager",
            font=("Segoe UI", 18, "bold"),
        ).pack(anchor="w")

        ttk.Label(
            outer,
            text=(
                "Build the application and compile the Windows installer "
                "in one operation."
            ),
            wraplength=680,
        ).pack(anchor="w", pady=(4, 18))

        ttk.Label(
            outer,
            text="Installer output folder",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w")

        folder_row = ttk.Frame(outer)
        folder_row.pack(fill="x", pady=(6, 14))

        self.output_var = tk.StringVar(value=str(DEFAULT_INSTALLER_OUTPUT))
        self.output_entry = ttk.Entry(folder_row, textvariable=self.output_var)
        self.output_entry.pack(side="left", fill="x", expand=True)

        self.browse_button = ttk.Button(
            folder_row,
            text="Browse…",
            command=self.choose_output,
        )
        self.browse_button.pack(side="left", padx=(8, 0))

        self.progress = ttk.Progressbar(
            outer,
            mode="determinate",
            maximum=100,
        )
        self.progress.pack(fill="x", pady=(2, 12))

        ttk.Label(
            outer,
            text="Build activity",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w")

        log_frame = ttk.Frame(outer)
        log_frame.pack(fill="both", expand=True, pady=(6, 14))

        self.log = tk.Text(
            log_frame,
            wrap="word",
            state="disabled",
            font=("Consolas", 9),
        )
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        self.log.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        buttons = ttk.Frame(outer)
        buttons.pack(fill="x")

        self.start_button = ttk.Button(
            buttons,
            text="Build Application and Installer",
            command=self.start_build,
        )
        self.start_button.pack(side="right")

        ttk.Button(
            buttons,
            text="Close",
            command=self.root.destroy,
        ).pack(side="right", padx=(0, 8))

        self.root.after(100, self.process_messages)

    def choose_output(self) -> None:
        selected = filedialog.askdirectory(
            title="Choose installer output folder",
            initialdir=self.output_var.get() or str(PROJECT_DIR),
        )
        if selected:
            self.output_var.set(selected)

    def append_log(self, text: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def set_controls_enabled(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        self.start_button.configure(state=state)
        self.output_entry.configure(state=state)
        self.browse_button.configure(state=state)

    def start_build(self) -> None:
        output = Path(self.output_var.get().strip())
        if not self.output_var.get().strip():
            messagebox.showwarning(
                "Output folder required",
                "Choose where the completed installer should be saved.",
            )
            return

        try:
            output.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            messagebox.showerror(
                "Invalid output folder",
                f"The selected output folder could not be created.\n\n{exc}",
            )
            return

        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        self.progress["value"] = 0
        self.set_controls_enabled(False)

        threading.Thread(
            target=self.run_build,
            args=(output,),
            daemon=True,
        ).start()

    def emit_log(self, text: str) -> None:
        self.messages.put(("log", text))

    def emit_progress(self, value: int) -> None:
        self.messages.put(("progress", value))

    def process_messages(self) -> None:
        try:
            while True:
                kind, value = self.messages.get_nowait()
                if kind == "log":
                    self.append_log(str(value))
                elif kind == "progress":
                    self.progress["value"] = int(value)
                elif kind == "finished":
                    success, detail = value
                    self.set_controls_enabled(True)
                    if success:
                        if messagebox.askyesno(
                            "Build complete",
                            "The application and installer were created successfully.\n\n"
                            "Open the installer output folder?",
                        ):
                            os.startfile(str(detail))
                    else:
                        messagebox.showerror(
                            "Build failed",
                            "The build could not be completed.\n\n"
                            f"{detail}\n\nReview the build activity for details.",
                        )
        except queue.Empty:
            pass

        self.root.after(100, self.process_messages)

    def run_command(self, command: list[str], cwd: Path) -> None:
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        process = subprocess.Popen(
            command,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags,
        )

        assert process.stdout is not None
        for line in process.stdout:
            self.emit_log(line.rstrip())

        code = process.wait()
        if code != 0:
            raise RuntimeError(
                f"Command failed with exit code {code}:\n{' '.join(command)}"
            )

    def find_inno_compiler(self) -> Path:
        candidates = [
            Path(os.environ.get("ProgramFiles(x86)", "")) / "Inno Setup 6" / "ISCC.exe",
            Path(os.environ.get("ProgramFiles", "")) / "Inno Setup 6" / "ISCC.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Inno Setup 6" / "ISCC.exe",
        ]

        found = shutil.which("ISCC.exe")
        if found:
            candidates.insert(0, Path(found))

        for candidate in candidates:
            if candidate and candidate.exists():
                return candidate

        raise RuntimeError(
            "Inno Setup 6 was not found. Install Inno Setup 6, then run "
            "build.bat again."
        )

    def run_build(self, installer_output: Path) -> None:
        try:
            self.emit_log("Step 1 of 6: Checking the build environment…")
            self.emit_progress(8)

            if not VENV_DIR.exists():
                self.emit_log("Creating the project build environment…")
                self.run_command(
                    [sys.executable, "-m", "venv", str(VENV_DIR)],
                    PROJECT_DIR,
                )
            else:
                self.emit_log("Existing project build environment found.")

            python_exe = VENV_DIR / "Scripts" / "python.exe"
            if not python_exe.exists():
                raise RuntimeError("The project build environment is incomplete.")

            self.emit_log("")
            self.emit_log("Step 2 of 6: Installing project requirements…")
            self.emit_progress(22)
            self.run_command(
                [str(python_exe), "-m", "pip", "install", "--upgrade", "pip"],
                PROJECT_DIR,
            )
            self.run_command(
                [
                    str(python_exe),
                    "-m",
                    "pip",
                    "install",
                    "-r",
                    str(PROJECT_DIR / "requirements.txt"),
                ],
                PROJECT_DIR,
            )

            self.emit_log("")
            self.emit_log("Step 3 of 6: Preparing the application build…")
            self.emit_progress(38)

            build_dir = PROJECT_DIR / "build"
            spec_file = PROJECT_DIR / f"{APP_NAME}.spec"

            if build_dir.exists():
                shutil.rmtree(build_dir, ignore_errors=True)
            if spec_file.exists():
                spec_file.unlink()
            if APP_EXE.exists():
                APP_EXE.unlink()

            self.emit_log("")
            self.emit_log("Step 4 of 6: Building the standalone executable…")
            self.emit_progress(52)
            self.run_command(
                [
                    str(python_exe),
                    "-m",
                    "PyInstaller",
                    "--noconfirm",
                    "--clean",
                    "--windowed",
                    "--onefile",
                    "--name",
                    APP_NAME,
                    "--distpath",
                    str(PROJECT_DIR),
                    "--workpath",
                    str(build_dir),
                    "--specpath",
                    str(PROJECT_DIR),
                    "--collect-all",
                    "PySide6",
                    str(PROJECT_DIR / "main.py"),
                ],
                PROJECT_DIR,
            )

            if not APP_EXE.exists():
                raise RuntimeError(
                    "PyInstaller finished, but the application executable "
                    "was not found in the project folder."
                )

            self.emit_log("")
            self.emit_log("Step 5 of 6: Locating Inno Setup…")
            self.emit_progress(76)
            iscc = self.find_inno_compiler()
            self.emit_log(f"Inno Setup compiler: {iscc}")

            self.emit_log("")
            self.emit_log("Step 6 of 6: Compiling the Windows installer…")
            self.emit_progress(86)
            self.run_command(
                [
                    str(iscc),
                    f"/O{installer_output}",
                    str(ISS_FILE),
                ],
                PROJECT_DIR,
            )

            installer = installer_output / "OCC_Inventory_Manager_Setup.exe"
            if not installer.exists():
                raise RuntimeError(
                    "Inno Setup finished, but the installer could not be found."
                )

            self.emit_progress(100)
            self.emit_log("")
            self.emit_log("Build completed successfully.")
            self.emit_log(f"Application: {APP_EXE}")
            self.emit_log(f"Installer: {installer}")
            self.messages.put(("finished", (True, installer_output)))

        except Exception as exc:
            self.emit_log("")
            self.emit_log(f"Build failed: {exc}")
            self.messages.put(("finished", (False, str(exc))))


def main() -> int:
    root = tk.Tk()
    BuildWindow(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
